<?php include("inc/header.php"); ?>
<?php 
include("classes/Idea.php");
$idea= new Idea();
if (!isset($_GET['idea'])||$_GET['idea']==NULL ||$_GET['idea']!=$_GET['idea']) {
    echo "<script>window.location = 'dashboard.php';</script>";
}else{
    // $id=$_GET['idea'];
    $id=preg_replace('/[^-a-zA-Z0-9]/', '', $_GET['idea']);
}
 if ($_SERVER['REQUEST_METHOD']=='POST'&& isset($_POST['update'])) {
   $userLog=$idea->update($_POST,$_FILES,$id);
     }
 ?>
        <!-- About Section -->
        <div class="contribute">
            
            <div class="container">
                
                <div class="row">
                    
                    <div class="col-md-12">
<?php include('inc/sidebar.php') ;?>
                        
                        
                        <div class="col-md-8">
                            
                            <div class="row">
                                <div class="col-xs-12">
                                    <h3 style="text-align:center;margin-bottom:30px;font-weight:bold;">Re-submit Your project Idea</h3>
                                    <?php if(isset($_SESSION['error'])) {?>
                                  <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                      <strong style="color: red;">Warning!</strong>
                                       <?php echo($_SESSION['error']);

                                       unset($_SESSION['error']);
                                       ?>
                                  </div>
                                <?php }?>
                                <?php if(isset($_SESSION['success'])) {?>
                                <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <strong style="color: green;">Success!</strong> 
                                    <?php echo($_SESSION['success']);

                                       unset($_SESSION['success']);
                                       ?>
                                  </div>
                                <?php }?>
                                <?php 
                                $getidea=$idea->getSigleIdea($id);
                                if ($getidea) {
                                   while ($result=$getidea->fetch_assoc()) {
                                 ?>
                                    <form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Project Category</label>
                                                <div class="col-sm-9">
                                                  <select class="form-control designalignment" id="sel1" name="project_type_id">
                                                    <?php 
                                                    $types=$idea->projectType();
                                                    if ($types) {
                                                       while ($type=$types->fetch_assoc()) {
                                                        if ($result['project_type_id']==$type['id']) {
                                                          
                                                     ?>
                                                    <option value="<?php echo($type['id']); ?>" selected><?php echo($type['name']); ?></option>
                                                    <?php }else{?>
                                                    <option value="<?php echo($type['id']); ?>"><?php echo($type['name']); ?></option>
                                                    <?php }}}else{?>
                                                    <option value=" ">Not found</option>
                                                    <?php } ?>
                                                  </select>
                                                </div>
                                               </div>
                                              
                                              <input type="hidden" value="<?php echo(Session::get('id'));?>" name="user_id">
                                              <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Project Title</label>
                                                <div class="col-sm-9">
                                                  <input type="text" class="form-control" placeholder="Project Title"  name="name" value="<?php echo($result['name']);?>" >
                                                </div>
                                              </div>

                                              <div class="form-group">
                                                    <label class="control-label col-sm-3 design" for="email">Project Image</label>
                                                <div class="col-sm-9">
                                            <p class="pull-left">
                                              <img id="blah" alt="" width="150" src="<?php echo($result['image']); ?>" class="rounded">
                                            </p>
                                            <span class="pull-right">
                                                  <input type="file" class="form-control"  placeholder="Upload Image" name="image">
                                            </span>
                                                </div>
                                              </div>
                                              <div class="form-group">
                                                    <label class="control-label col-sm-3 design" for="email">Project Document</label>
                                                <div class="col-sm-9">
                                                  <p class="pull-left">
                                                  <input type="file" class="form-control"  placeholder="Upload project doument" name="document">

                                            </p>
                                            <span class="pull-right">
                                          <a class="btn btn-info" target="_blank" href="<?php echo($result['document']); ?>">Open Document</a>

                                            </span>
                                                </div>
                                              </div>
                                              <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Project Description</label>
                                                <div class="col-sm-9">
                                                    <textarea class="form-control" rows="5" id="comment" name="content"><?php echo($result['content']);?></textarea>
                                                </div>
                                              </div>
                                            
                                            
                                            <div class="form-group">
                                              <div class="col-sm-offset-3 col-sm-9">
                                                <button type="submit" class="btn btn-primary" name="update">Update</button>
                                                <button type="submit" class="btn btn-primary">Back</button>
                                              </div>
                                            </div>
                                          </form>
                                          <?php }} ?>
                                 </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    


<?php include("inc/footer.php"); ?>
  