﻿<?php include("inc/header.php"); ?>
<?php 
include("classes/Idea.php");
$idea= new Idea();
 if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['idea'])) {
   $userLog=$idea->insertIdea($_POST,$_FILES);
     }
  if (isset($_GET['rating'])) {
    $idea->rating($_GET['rating']);
  }
 ?>
 <!-- About Section -->
<div class="contribute">
     
    <div class="container">
    
       <div class="row">
     
           <div class="col-md-12">
              <div class="col-md-3">
             <div class="row">
                  <div class="col-md-4">
                    <a href="profile.php">
              <div class="customDivprofile">
                
              <img height="202" width="200" src="<?php echo(Session::get('image'));?>" class="img-rounded" alt="Cinque Terre">
               
              </div>
              </a>
                </div>     
             </div>
             <div class="contribute_profile">
                <h3><?php echo(Session::get('name'));?></h3>
              <p>Don't waste your time trying to impress other people. Do what you love, love what you do.</p>
               <button style="margin-right:250px;font-weight:bold;width:200px;margin-top:20px;background:#E7ECF1;border:1px solid #CFD4D8;color:black;" class="btn" data-dismiss="modal">Follow</button>
               <i class="fa fa-map-marker  "> Belkuchi-sirajgong</i><br/>
               <i class="fa fa-user "> <a style="text-decoration:underline;color:#2279DB;" href="">  https://www.facebook.com</a></i><br/>
               <i class="fa fa-user "> <a style="text-decoration:underline;color:#2279DB;" href="">   https://mail.google.com</a></i>
             </div>
          </div>
          
          <div class="col-md-8">
          
           <div class="row">
     <div class="col-xs-12">
        <ul class="nav nav-tabs">
         <li class="active">
        <a href="#overviewTab" data-toggle="tab">Overview</a>
        </li>
        <li>
        <li>
        <a href="#repositoryTap" data-toggle="tab">Repositories <span class="badge">10</span></a>
        </li>
        </li>
        <li>
        <a href="idea-add.php" class="btn btn-default">Post Idea 
        </a>
        
        </li>
      </ul>
      <?php if(isset($_SESSION['error'])) {?>
        <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong style="color: red;">Warning!</strong>
             <?php echo($_SESSION['error']);

             unset($_SESSION['error']);
             ?>
        </div>
      <?php }?>
      <?php if(isset($_SESSION['success'])) {?>
      <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <strong style="color: green;">Success!</strong> 
          <?php echo($_SESSION['success']);

             unset($_SESSION['success']);
             ?>
        </div>
      <?php }?>
      <div class="tab-content">
         <div id="overviewTab" class="tab-pane fade in active">
       
            <div class="row">
          <div class="col-md-12">
            <?php 
              $getideas=$idea->getAllIdeas();
              if ($getideas) {
                 while ($result=$getideas->fetch_assoc()) {
             ?>
              <div class="col-md-6">
              <div class="customDividea">
              <i style="margin-left:150px;font-size:30px;padding:5px;margin-bottom:0px;color:#2279DB;" class="fa fa-lightbulb-o"></i>
              <h3 style="text-align:center;" ><a style="color:#2279DB;font-size:13px;font-weight:bold;" href="idea-view.php?idea=<?php echo($result['id']); ?>"><?php echo($result['name']); ?></a></h3> 
              </div>
                </div>
              <?php }} ?>
             
            </div>
             </div>
       
        
 </div>
       <!-- write code repository tab -->
       
       <div id="repositoryTap" class="tab-pane">
       
             <div class="row">
               <div class="container">
              <div class="col-md-8">
                 <div class="customDivRepo">
                
                 <?php 
                $reidea=$idea->getAllPostIdea();
                if ($reidea) {
                   while ($re=$reidea->fetch_assoc()) {
               ?>
                <hr/>
              <h3><a style="color:#2279DB;font-size:13px;font-weight:bold;" href="idea-view.php?idea=<?php echo($re['id']); ?>"><?php echo($re['name']);?></a></h3> 
              <h4>Submit date: <?php echo(date('d M Y', strtotime($re['created_at']))); ?></h4>
              <span class="alignstar">
                <a href="?rating=<?php echo($re['id']); ?>" class="btn btn-primary"><i class="fa fa-star-o"><?php echo($re['rating']!=0?$re['rating']:''); ?></i></a>
            </span>
              <span class="alignstar">
              <i class="fa fa-eye"><?php echo($re['view']!=0?$re['view']:''); ?> </i></span>
              <hr/>
              <?php }} ?>
              </div>  
             </div>
            </div>
           </div>
           
       </div>
       
      </div>
  
      </div>
      
    </div>
   </div> 
          
      </div>
         </div>
    
     </div>
    
  
   
 </div>
 
 

 
 

</div>

<?php include("inc/footer.php"); ?>
  