<?php 
include('inc/header.php') ;
include('classes/User.php') ;
$user=new User();
if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['registration'])) {
 $userReg=$user->userRegtration($_POST,$_FILES);
   }
?>


<!-- About Section -->
<style>
	.hide{display: none;}
</style>
<div id="about">
  <div class="container">
    <div class="col-xs-12 col-md-6 col-md-offset-1 section-title text-center">
      <h2>Join DIU Idea portal</h2>
      <h5>This is the best way share your idea</h5>
	
	  
	  <div class="row">
	    <div class="container">
		
		  <div class="col-md-12">
		    <div class="row">
			  <div class="col-md-3 col-md-offset-1">
					<div class="customDiv">
					<h3>Step 1:</h3>
					  <i class="fa fa-user"></i>
					  <p>Create your Personal Account</p>
					</div>
			  </div>
			  <div class="col-md-3">
					<div class="customDiv">
							<h3>Step 2:</h3>
					  <i class="fa fa-cogs"></i>
					  <p>Choose Your Plan </p>
					</div>
			  </div>
			  <div class="col-md-3">
					<div class="customDiv">
							<h3>Step 3:</h3>
					  <i class="fa fa-cogs"></i>
					  <p>Provide your Experience</p>
					</div>
			  </div>
           </div>
		 </div>   
	</div>
  </div>
  <?php $i=1; ?>
  <h4>Step <span id="sl">1</span>:</h4>
  <h6 id="LabelID">Create your personal account </h6>
  <?php  if(isset($_SESSION['error'])){?>
  	<h3 class="text-danger"><strong>Warning!</strong></h3>
  <?php } ?>
  
  </div>
  
  
  
	<div class="container"> 
      <div class="row"> 
	     <div class="col-xs-12"> 
		     <div class="modal fade" data-keyboard="false" data-backdrop="static" id="loginModal2" tabindex="-1">
			    <div class="modal-dialog">
				   <div class="modal-content">
				      <div class="modal-header">
					     <button class="close" data-dismiss="modal">&times;</button>
						 
					   </div>
					   <div class="modal-body">
					   <h2>Terms of Services</h2>
					      <h4>1.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  <h4>2.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						  <h4>3.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						  <h4>4.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						  <h4>5.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						   
					   </div>
					   <div class="modal-footer">
					    <button style="margin-right:250px;font-weight:bold;" class="btn btn-primary" data-dismiss="modal">Close</button>
					   </div>
					 </div>
				 </div>
			  </div>
		</div>
	 </div>
	</div>
	
	<div class="container"> 
      <div class="row"> 
	     <div class="col-xs-12"> 
		     <div class="modal fade" data-keyboard="false" data-backdrop="static" id="loginModal3" tabindex="-1">
			    <div class="modal-dialog">
				   <div class="modal-content">
				      <div class="modal-header">
					     <button class="close" data-dismiss="modal">&times;</button>
						 
					   </div>
					   <div class="modal-body">
					      <h2>Privacy statement</h2>
						 <h4>1.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						   <h4>2.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						  <h4>3.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						  <h4>4.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						  
						  <h4>5.Terms</h4>
						  <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this web site are protected by applicable copyright and trade mark law.</p>
						   
					   </div>
					   <div class="modal-footer">
					    <button style="margin-right:250px;font-weight:bold;" class="btn btn-primary" data-dismiss="modal">Close</button>
					   </div>
					 </div>
				 </div>
			  </div>
		</div>
	 </div>
	</div>
	
	
    <div class="row">
       <div class="col-xs-12 col-md-8 col-md-offset-2 form_leftalignment">
       	<?php if(isset($_SESSION['error'])) {?>
                                  <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                      <strong style="color: red;">Warning!</strong>
                                       <?php echo($_SESSION['error']);

                                       unset($_SESSION['error']);
                                       ?>
                                  </div>
                                <?php }?>
                                <?php if(isset($_SESSION['success'])) {?>
                                <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <strong style="color: green;">Success!</strong> 
                                    <?php echo($_SESSION['success']);

                                       unset($_SESSION['success']);
                                       ?>
                                  </div>
                                <?php }?>
	     <form method="POST" action="" enctype="multipart/form-data">
		 <?php  
		 for ($i = 1; $i <=3; $i++){

		 if ($i==1){?>
		 <div id='question<?php echo($i);?>' class='cont'>
		    <div class="form-group">
			  <label style="font-weight:bold;" for="inputUserName">UserName</label>
			  <input class="form-control" placeholder="Please Enter your name" type="text" name="name" value=""/>
			</div> 
			 <div class="form-group">
			  <label style="font-weight:bold;" for="inputUserName">Email</label>
			  <input id="email" type="email" class="form-control" name="email" value=""  autocomplete="email">
			 </div>
			 <div class="form-group">
			  <label style="font-weight:bold;" for="inputUserName">Student ID</label>
			  <input id="student_id" type="text" class="form-control" name="student_id" value="" placeholder="0000-00-0000"  autocomplete="student_id">
			 </div>
			 <div class="form-group">
			   <label style="font-weight:bold;" for="inputPassword">Select Department</label>
			  <select class="form-control" name="department">
			     <option></option>
			     <option value="1">CSE</option>
				  <option value="2">CIS</option>
				  <option value="3">MCT</option>
			   </select>
			 </div>
			 <div class="form-group">
			   <label style="font-weight:bold;" for="inputPassword">Select Semister</label>
			  <select class="form-control" name="semister">
			     <option></option>
			     <option value="spring">Spring</option>
			     <option value="fall">Fall</option>
			     <option value="summar">Summar</option>
			   </select>
			 </div>
			 <div class="form-group">
			   <label style="font-weight:bold;" for="inputPassword">Password</label>
			   <input id="password" type="password" class="form-control" name="password"  autocomplete="new-password">
			 </div>
			  <div class="form-group">
			   <label style="font-weight:bold;" for="inputPassword">Confirm Password</label>
			   <input id="password-confirm" type="password" class="form-control" name="password_confirmation"  autocomplete="new-password">
			 </div>
			 <button id='<?php echo($i);?>' class='next btn btn-success' type='button'>Next</button>
			 </div>
			 <?php }elseif($i < 1 || $i < 3){ ?>
			 <div id='question<?php echo($i);?>' class='cont'>
			 <div class="form-group">
			   <label style="font-weight:bold;" for="inputPassword">Choose file</label>
			  <input class="form-control" placeholder="Please Enter your name" type="file" id="inputPassword" name="image" />
			 </div>
			 <button id='<?php echo($i);?>' class='previous btn btn-success' type='button'>Previous</button>                    
            <button id='<?php echo($i);?>' class='next btn btn-success' type='button' >Next</button>
			 </div>
			<?php }elseif($i==3){?>
			 <div id='question<?php echo($i);?>' class='cont'>
			 <div class="form-group">
			   <label style="font-weight:bold;" for="inputPassword">Language</label><br/>
			   <input type="text" id="tags" value="Php,Laravel,Bootstrap" class="form-control" name="language" data-role="tagsinput">
			 	
			 </div>
			 <div class="form-group">
			   <p>By clicking “Create an account” below, you agree to our <a style="color:#0366D6;" data-target="#loginModal2" data-toggle="modal" href="">terms of service</a> and <a style="color:#0366D6;" data-target="#loginModal3" data-toggle="modal" href="">Privacy statement</a>. We’ll occasionally send you account related emails.</p>
			 </div>
			 <button id='<?php echo($i);?>' class='previous btn btn-success' type='button'>Previous</button>                    
            <button  class='next btn btn-success' type='submit' name="registration">Create an Account</button>
			 </div>
			<?php  }}?>
			
		  </form>
		  <br/>
          <div class="row">
          <div class="well well-sm">
            <p style="color:black;text-align:center;margin-top:7px;">New to DIU Idea Portal?<a style="color:#0366D6;" href="login.php">  Login</a></p>
		</div>
		</div>
	   </div>
    </div>
  </div>
</div>


<?php include('inc/footer.php') ;?>
<script>
$( document ).ready(function() {
	console.log( "ready yrar!" );
	$('.cont').addClass('hide');
		count=$('.questions').length;
		 $('#question'+1).removeClass('hide');
		 
		 $(document).on('click','.next',function(){
			
		     last=parseInt($(this).attr('id'));
			 if (last==1) {
				$("#sl").empty();
				$("#sl").append('2');
				$("#LabelID").empty();
				$("#LabelID").append("ID Cart Image");
			}else if (last==2){
				$("#sl").empty();
				$("#sl").append('3');
				$("#LabelID").empty();
				$("#LabelID").append("Provide your Experience");
			}
			   
		     nex=last+1;
		     $('#question'+last).addClass('hide');
		     
		     $('#question'+nex).removeClass('hide');
		 });
		 
		 $(document).on('click','.previous',function(){
             last=parseInt($(this).attr('id'));     
             pre=last-1;
			 if (pre==1) {
				$("#sl").empty();
				$("#sl").append('1');
				$("#LabelID").empty();
				$("#LabelID").append("Create your personal account");
			}else if (pre==2){
				$("#sl").empty();
				$("#sl").append('2');
				$("#LabelID").empty();
				$("#LabelID").append("ID Cart Image");
			}
             $('#question'+last).addClass('hide');
             
             $('#question'+pre).removeClass('hide');
		 });
		 $('#tags').tagsInput({
      width: 'auto'
    });
});
</script>
