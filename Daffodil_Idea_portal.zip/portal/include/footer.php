<footer class="footer-area" style="background-color: #005691">
        <!--Footer Upper-->
        <div class="footer-content" style="background-color: #005691">
            <div class="container">
                <div class="row clearfix">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="footer-content text-center no-padding margin-bottom-40">
                            <div class="logo-footer">
                                <img id="logo-footer" class="center-block" src="images/logo-1.png" alt="">
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus illo vel dolorum soluta consectetur doloribus sit. Delectus non tenetur odit dicta vitae debitis suscipit doloribus. Lorem ipsum dolor sit amet, illo vel.</p>
                        </div>
                    </div>
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            <div class="col-lg-7 col-sm-6 col-xs-12 column">
                                <div class="footer-widget about-widget">
                                    <h2>Our Addres</h2>
                                    <ul class="contact-info">
                                        <li><span class="icon fa fa-map-marker"></span> 60 Link Road Lhr. Pakistan 54770</li>
                                        <li><span class="icon fa fa-phone"></span> (042) 1234567890</li>
                                        <li><span class="icon fa fa-map-marker"></span> contant@scriptsbundle.com</li>
                                        <li><span class="icon fa fa-fax"></span> (042) 1234 7777</li>
                                    </ul>
                                    <div class="social-links-two clearfix">
                                        <a href="#" class="facebook img-circle">    <span class="fa fa-facebook-f"></span>
                                        </a>
                                        <a href="#" class="twitter img-circle"> <span class="fa fa-twitter"></span>
                                        </a>
                                        <a href="#" class="google-plus img-circle"> <span class="fa fa-google-plus"></span>
                                        </a>
                                        <a href="#" class="linkedin img-circle"> <span class="fa fa-pinterest-p"></span>
                                        </a>
                                        <a href="#" class="linkedin img-circle">    <span class="fa fa-linkedin"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!--Footer Column-->
                            <div class="col-lg-5 col-sm-6 col-xs-12 column">
                                <h2>Our Service</h2>
                                <div class="footer-widget links-widget">
                                    <ul>
                                        <li><a href="#">Web Development</a>
                                        </li>
                                        <li><a href="#">Web Designing</a>
                                        </li>
                                        <li><a href="#">Android Development</a>
                                        </li>
                                        <li><a href="#">Theme Development</a>
                                        </li>
                                        <li><a href="#">IOS Development</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Two 4th column End-->
                    <!--Two 4th column-->
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            <!--Footer Column-->
                            <div class="col-lg-7 col-sm-6 col-xs-12 column">
                                <div class="footer-widget news-widget">
                                    <h2>Latest News</h2>
                                    <!--News Post-->
                                    <div class="news-post">
                                        <div class="icon"></div>
                                        <div class="news-content">
                                            <figure class="image-thumb">
                                                <img src="images/blog/popular-2.jpg" alt="">
                                            </figure> <a href="#">If you need a crown or lorem an implant you will pay it gap it</a>
                                        </div>
                                        <div class="time">July 2, 2014</div>
                                    </div>
                                    <!--News Post-->
                                    <div class="news-post">
                                        <div class="icon"></div>
                                        <div class="news-content">
                                            <figure class="image-thumb">
                                                <img src="images/blog/popular-1.jpg" alt="">
                                            </figure> <a href="#">If you need a crown or lorem an implant you will pay it gap it</a>
                                        </div>
                                        <div class="time">July 2, 2014</div>
                                    </div>
                                </div>
                            </div>
                            <!--Footer Column-->
                            <div class="col-lg-5 col-sm-6 col-xs-12 column">
                                <div class="footer-widget links-widget">
                                    <h2>Site Links</h2>
                                    <ul>
                                        <li><a href="login.php">Login</a>
                                        </li>
                                        <li><a href="login.php">Register</a>
                                        </li>
                                        <li><a href="contact.php">Contact Us</a>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Two 4th column End-->
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="footer-copyright" style="background-color: #005691; color:white;">
            <div class="auto-container clearfix">
                <!--Copyright-->
                <div class="copyright text-center">Copyright 2019 &copy; Theme Created By <a >Kawser</a> All Rights Reserved</div>
            </div>
        </div>
    </footer>
    <!-- =-=-=-=-=-=-= JQUERY =-=-=-=-=-=-= -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap Core Css  -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Jquery Smooth Scroll  -->
    <script src="js/jquery.smoothscroll.js"></script>
    <!-- Jquery Easing -->
    <script type="text/javascript" src="js/easing.js"></script>
    <!-- Jquery Counter -->
    <script src="js/jquery.countTo.js"></script>
    <!-- Jquery Waypoints -->
    <script src="js/jquery.waypoints.js"></script>
    <!-- Jquery Appear Plugin -->
    <script src="js/jquery.appear.min.js"></script>
    <!-- Carousel Slider  -->
    <script src="js/carousel.min.js"></script>
    <!-- Jquery Parallex -->
    <script src="js/jquery.stellar.min.js"></script>
    <!--Style Switcher -->
    <script src="js/bootstrap-dropdownhover.min.js"></script>
    <!-- Include jQuery Syntax Highlighter -->
    <script type="text/javascript" src="scripts/shCore.js"></script>
    <script type="text/javascript" src="scripts/shBrushPhp.js"></script>
    <!-- Template Core JS -->
    <script src="js/custom.js"></script>
</body>


<!-- Mirrored from templates.scriptsbundle.com/knowledge/demo/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 23 Nov 2019 14:43:26 GMT -->
</html>