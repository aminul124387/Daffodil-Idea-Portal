<!-- =-=-=-=-=-=-= Search Bar =-=-=-=-=-=-= -->
  <div class="full-section search-section-listing">
    <div class="search-area container">
      <h3 class="search-title">Have a Question?</h3>
      <p class="search-tag-line">If you have any question you can ask below or enter what you are looking for!</p>
      <form action="question-search.php" autocomplete="off" method="post" class="search-form clearfix" id="search-form">
        <input type="text" title="* Please enter a search term!" placeholder="Search by problem or subject name" class="search-term " autocomplete="off" name="search">
        <input type="submit" value="Search" class="search-btn" name="questionSearch">
      </form>
    </div>
  </div>
  <!-- =-=-=-=-=-=-= Search Bar END =-=-=-=-=-=-= -->