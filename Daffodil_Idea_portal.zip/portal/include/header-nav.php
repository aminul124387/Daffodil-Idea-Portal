    <div class="navbar navbar-default">
        <div class="container">
            <!-- header -->
            <div class="navbar-header">
                <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">  <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- logo -->
                <a href="index.php" class="navbar-brand">
                    <img class="img-responsive" alt="" src="images/loggo.png">
                </a>
                <!-- header end -->
            </div>
            <!-- navigation menu -->
            <div class="navbar-collapse collapse">
                <!-- right bar -->
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden-sm"><a href="how-works.php">How  It Works</a>
                    </li>
                    <li><a href="question-list.php">Browse Questions</a>
                    </li>
                    <li>
                        <div class="btn-nav"><a href="question-post.php" class="btn btn-primary btn-small navbar-btn">Post Question</a>
                        </div>
                    </li>
                </ul>
            </div>
            <!-- navigation menu end -->
            <!--/.navbar-collapse -->
        </div>
    </div>