﻿<?php include("inc/header.php"); ?>
<?php 
include("classes/User.php");
$user= new User();
?>
 <?php 
if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['changeAccount'])) {
    $user->changeUserAccount($_POST,$_FILES);
}
if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['changePassword'])) {
    $user->changePassword($_POST);
}
 ?>
 <!-- About Section -->
<div class="contribute">
     
    <div class="container">
    
       <div class="row">
     
           <div class="col-md-12">
              <div class="col-md-3">
             <div class="row">
                  <div class="col-md-4">
              <div class="customDivprofile">
                <a href="profile.php">
              <img height="202" width="200" src="<?php echo(Session::get('image'));?>" class="img-rounded" alt="Cinque Terre">
               </a>
              </div>
                </div>     
             </div>
             <div class="contribute_profile">
                <h3><?php echo(Session::get('name'));?></h3>
              <p>Don't waste your time trying to impress other people. Do what you love, love what you do.</p>
               <button style="margin-right:250px;font-weight:bold;width:200px;margin-top:20px;background:#E7ECF1;border:1px solid #CFD4D8;color:black;" class="btn" data-dismiss="modal">Follow</button>
               <i class="fa fa-map-marker  "> Belkuchi-sirajgong</i><br/>
               <i class="fa fa-user "> <a style="text-decoration:underline;color:#2279DB;" href="">  https://www.facebook.com</a></i><br/>
               <i class="fa fa-user "> <a style="text-decoration:underline;color:#2279DB;" href="">   https://mail.google.com</a></i>
             </div>
          </div>
          
          <div class="col-md-8">
          
           <div class="row">
     <div class="col-xs-12">
        <ul class="nav nav-tabs">
         <li class="active">
        <a href="#overviewTab" data-toggle="tab">Update Profile </a>
        </li>
        <li>
        <li>
        <a href="#repositoryTap" data-toggle="tab">Change Password <span class="badge"></span></a>
        </li>
        </li>
        <li>
        <a href="idea-add.php" class="btn btn-default">Post Idea 
        </a>
        
        </li>
      </ul>
      <div class="tab-content">
         <div id="overviewTab" class="tab-pane fade in active">
        <div class="container">
     <div class="row">
         <div class="col-md-8">
       <hr/><br/>

         <h3>Update Profile</h3>
       <?php if(isset($_SESSION['error'])) {?>
        <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong style="color: red;">Warning!</strong>
             <?php echo($_SESSION['error']);

             unset($_SESSION['error']);
             ?>
        </div>
      <?php }?>
      <?php if(isset($_SESSION['success'])) {?>
      <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <strong style="color: green;">Success!</strong> 
          <?php echo($_SESSION['success']);

             unset($_SESSION['success']);
             ?>
        </div>
      <?php }?>
        <form method="post" action="" enctype="multipart/form-data">
          <div class="form-group">
         <label style="font-weight:bold;" for="inputPassword">UserName</label>
        <input class="form-control" placeholder="Please Enter your name" type="text" name="name" value=""/>
       </div>
        <div class="form-group">
         <label style="font-weight:bold;" for="inputPassword">Image</label>
        <input class="form-control" placeholder="Please Enter your name" type="file" name="user_img" value=""/>
       </div>
      <button  class='next btn btn-success' type='submit' name="changeAccount">Update Profile</button>
      </form>
       </div>
   </div>
     </div>
 </div>
       <!-- write code repository tab -->
       
       <div id="repositoryTap" class="tab-pane">

         <div class="container">
     <div class="row">
         <div class="col-md-8">
       <hr/><br/>

         <h3>Change Password</h3>
        <form method="post">
          <div class="form-group">
         <label style="font-weight:bold;" for="inputPassword">Old Password</label>
        <input class="form-control" placeholder="Please Enter Old Password" type="password" name="old-pass" value=""/>
       </div>
        <div class="form-group">
         <label style="font-weight:bold;" for="inputPassword">New Password</label>
        <input class="form-control" placeholder="Please Enter New Password" type="password" name="new-pass" value=""/>
       </div>
       <button  class='next btn btn-success' type='submit' name="changePassword">Change Password</button>

      </form>
       </div>
   </div>
     </div>
       
       </div>
       
      </div>
  
      </div>
      
    </div>
   </div> 
          
      </div>
         </div>
    
     </div>
    
  
   
 </div>
 
 

 
 

</div>

<?php include("inc/footer.php"); ?>
  