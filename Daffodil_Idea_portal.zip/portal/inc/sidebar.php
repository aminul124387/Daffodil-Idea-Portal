<div class="col-md-3">
                            <div style="padding:5px;border:5px solid #007D8B;border-radius:5px;height:500px;" class="clickablelink">
                                
                                <ul>
                                    
                                    <li style="text-align:center;padding:4px;background:#007D8B;border-radius:4px;margin-bottom:5px;min-height:90px;"><a style="color:black;font-weight:bold;color:#FFFFFF;" href="dashboard.php"><i class="fa fa-lightbulb-o "></i>Dashboard</a></li> 
                                    <li style="text-align:center;padding:4px;border:3px solid #007D8B;border-radius:4px;margin-bottom:5px;"><a style="color:black;font-weight:bold;" href="idea-add.php"><i class="fa fa-lightbulb-o "></i> Post Idea</a></li> 
                                   <li style="text-align:center;padding:4px;border:3px solid #007D8B;border-radius:4px;margin-bottom:5px;"><a style="color:black;font-weight:bold;" href="#"><i class="fa fa-lightbulb-o "></i>View Post</a></li> 
                                    
                                    <li style="text-align:center;padding:4px;border:3px solid #007D8B;border-radius:4px;margin-bottom:5px;"><a style="color:black;font-weight:bold;" href="#"><i class="fa fa-lightbulb-o "></i>View Best Post</a></li> 
                                    <li style="text-align:center;padding:4px;border:3px solid #007D8B;border-radius:4px;margin-bottom:5px;"><a style="color:black;font-weight:bold;" href="#"><i class="fa fa-lightbulb-o "></i> Find Freind</a></li> 
                                    
                                    <li style="text-align:center;padding:4px;border:3px solid #007D8B;border-radius:4px;margin-bottom:5px;"><a style="color:black;font-weight:bold;" href="#"><i class="fa fa-lightbulb-o "></i>Log Out</a></
                                    
                                    
                                    
                                </ul>
                                
                            </div>
                            
                        </div>


