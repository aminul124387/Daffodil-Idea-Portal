<?php ob_start(); ?>
<?php 
include 'lib/Session.php'; 
Session::init();
/*
$login= Session::get("userlogin");
if ($login==false) {
   header("Location:login.php");
}*/
include_once 'lib/Database.php';
include_once 'helpers/Format.php'; 
$db=new Database();
$fm=new Format();
?>
<?php
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache"); 
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
  header("Cache-Control: max-age=2592000");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Idea portal</title>
<meta name="description" content="">
<meta name="author" content="">

<!-- Favicons
    ================================================== -->
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">

<!-- Stylesheet
    ================================================== -->
<link rel="stylesheet" type="text/css"  href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/modernizr.custom.js"></script>

<link rel="stylesheet" type="text/css"  href="css/design.css">
<!--taginout-->
<link rel="stylesheet" type="text/css"  href="css/select2.min.css">
<link rel="stylesheet" type="text/css"  href="css/jquery.tagsinput.min.css">



</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Navigation -->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    

      <a class="navbar-brand page-scroll" href="#page-top"><i style="color:yellow;font-size:45px;" class="fa fa-lightbulb-o "></i> <span style="color:red;font-weight:bold;font-size:30px;">I</span><span style="color:yellow;font-weight:bold;font-size:30px;">d</span><span style="color:white;font-weight:bold;font-size:30px;">e</span><span style="color:pink;font-weight:bold;font-size:30px;">a</span> portal</a> </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php" class="page-scroll">Home</a></li>
        <?php
         $login= Session::get("userlogin");
          if ($login!=false) {?>
        <li><a href="dashboard.php" class="page-scroll">Dashbord</a></li>
        <?php } ?>
        <li><a href="#services" class="page-scroll">Services</a></li>
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#portfolio" class="page-scroll">Portfolio</a></li>
        <?php 
            if (isset($_GET['uid'])) {
              $userid= Session::get("id");
              Session::destroyUser();
            }
       ?>
         <?php
           $login= Session::get("userlogin");
          if ($login==false) {?>
        <li><a href="login.php" class="page-scroll">Login</a></li>
        <?php }else{?>
        <li>
          <a href="?uid=<?php Session::get('id');?>" class="page-scroll">Logout</a>
        </li>
        <?php } ?>
        <li><a href="#contact" class="page-scroll">Contact</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>
<!-- Header -->