             <div class="container">
               <div class="row">
                <div class="col-xs-12 col-md-4 col-md-offset-4">
                        <div style="background-color:#FFFFFF;border:1px solid #FFFFFF;" class="well well-sm">
                        <p style="color:black;text-align:center;margin-top:7px;"><a style="color:#0366D6;font-weight" href="index.php"> Home |</a><a style="color:#0366D6;" href=""> Privacy |</a><a style="color:#0366D6;" href=""> Security |</a><a style="color:#0366D6;" href=""> Contact Us</a></p>
                       </div>
                    </div>
                </div>
            </div>
   
</div>

</body>
</html>