<?php 
	/*Update credentials*/
	define('EMAIL', '1000223@daffodil.ac'); 
	define('PASS', '1coaching!'); 
	define('API_KEY', 'AIzaSyDguqKVbN5avuwtSdLAe1It-59Coj0ATbk'); 
 ?>