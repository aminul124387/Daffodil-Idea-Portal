<?php 
$filepath=realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../lib/Session.php');
Session::init();
include_once($filepath.'/../helpers/Format.php'); 
require_once './vendor/autoload.php';
require 'credential.php';
 ?>
<?php 
class User{
	private $db;
	private $fm;
	public function __construct(){
		$this->db=new Database();
		$this->fm=new Format();	

	}
	public function userRegtration($data,$file){
		
		$name=mysqli_real_escape_string($this->db->link,$data['name']);
		$email=mysqli_real_escape_string($this->db->link,$data['email']);
		$student_id=mysqli_real_escape_string($this->db->link,$data['student_id']);
		$department=mysqli_real_escape_string($this->db->link,$data['department']);
		$semister=mysqli_real_escape_string($this->db->link,$data['semister']);
		$password=mysqli_real_escape_string($this->db->link,$data['password']);

		$password2=mysqli_real_escape_string($this->db->link,$data['password_confirmation']);
		$language=mysqli_real_escape_string($this->db->link,$data['language']);
		$image=mysqli_real_escape_string($this->db->link,$file['image']['name']);
		$typeofuser="student";
		if ($name==""||$email==""||$student_id==""||$department==""||$semister==""||$password==""||$password2==""||$language=="") {
			$_SESSION['error']= "<span class='error'> field must not be empty </span>";
			return $this->redirect();
             }
             if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		         $_SESSION['error']="<span class='error'>Invalid Email</span>";
		        return $this->redirect();
	        }
	        if (!strstr($email, 'diu.edu.bd')) {
			     $_SESSION['error']="<span class='error'>Only Allow DIU Email Address.</span>";
		        return $this->redirect();
			}
			
			if (!preg_match('/^[0-9]{3}-[0-9]{2}-[0-9]{3}+$/', $student_id)) {
				$_SESSION['error']= "<span>Enter valid Student ID </span>";
				return $this->redirect();
			}
             if ($password!=$password2) {
             	$_SESSION['error']= "<span>Password not matched </span>";
				return $this->redirect();
             }
             
             
             $eml="select * from users where email='$email' limit 1";
             $emlcheck=$this->db->select($eml);
             if ($emlcheck <> false){
             	$_SESSION['error']="<span class='error'>Email  already exist !</span>";
				return $this->redirect();
             }
              $permited  = array('jpg', 'jpeg', 'png', 'gif');
			$file_name = $file['image']['name'];
			$file_size = $file['image']['size'];
			$file_temp = $file['image']['tmp_name'];
			$div = explode('.', $file_name);
			$file_ext = strtolower(end($div));
			$unique_image = uniqid() .'-'.rand(1,100).'.'.$file_ext;
			$uploaded_image = "img/upload/".$unique_image;
			if ($file_size >(1048567*2)) {
			     $_SESSION['error']="<span class='error'>Image Size should be less then 2MB!
			     </span>";
			    }elseif (in_array($file_ext, $permited) === false) {
			     $_SESSION['error']="<span class='error'>You can upload only:-"
			     .implode(', ', $permited)."</span>";

			 }else{
             	$pass=md5($password);
             	move_uploaded_file($file_temp, $uploaded_image);
             	$query ="INSERT INTO users(name,email,student_id,department,semister,password,language,image,types)
                VALUES('$name','$email','$student_id','$department','$semister','$pass','$language', '$uploaded_image','$typeofuser')";

             	$UserInsert=$this->db->insert($query);
				if ($UserInsert) {
					$_SESSION['success']="<span class='success'>user data insert successful plesde login</span>";
					return $this->redirect();
				}else{
					$_SESSION['error']="<span class='error'>user data  not insert .</span>";
					return $this->redirect();
				}
			 	
			 }
	}
	
	public function userLogin($ldata){
		
		$student_id=mysqli_real_escape_string($this->db->link,$ldata['email']);
		$password=mysqli_real_escape_string($this->db->link,md5($ldata['password']));
		if (empty($student_id)||empty($password)){
			$_SESSION['error']="<span>Field must not be empty</span>";
			return;
		}
		$query = "select * from users where email='$student_id' AND password='$password'";
		$result=$this->db->select($query);
		if ($result!=false) {
			$value=$result->fetch_assoc();
			Session::set("userlogin",true);
			Session::set("id",$value['id']);
			Session::set("name",$value['name']);
			Session::set("email",$value['email']);
			Session::set("image",$value['user_img']);
			Session::set("type",$value['type']);
			Session::set("role",$value['role']);
			if ($value['role']!=3) {
			header("Location: admin/dashboard.php");
			}else{
			header("Location: dashboard.php");
			}
			
		}else{
			$_SESSION['error']= "<span class='error'> email or password not matched! </span>";
			return;
		}

	}
	public function changeUserAccount($data,$file)
	{
		var_dump($data);
			$name=mysqli_real_escape_string($this->db->link,$data['name']);
			$image=mysqli_real_escape_string($this->db->link,$file['user_img']['name']);
			if ($name==""||$image=="") {
				$_SESSION['error']= "<span class='error'> Field must not be empty </span>";
				return $this->redirect();
	             }
		       
				$user_id=Session::get("id");
		        $permited  = array('jpg', 'jpeg', 'png', 'gif');
				$userUpdate='';
			     
			    $file_name = $file['user_img']['name'];
				$file_size = $file['user_img']['size'];
				$file_temp = $file['user_img']['tmp_name'];
				$div = explode('.', $file_name);
				$file_ext = strtolower(end($div));
				$unique_image = uniqid() .'-'.rand(1,100).'.'.$file_ext;
				$uploaded_image = "img/upload/user/".$unique_image;

			    if ($file_size >(1048567*2)) {
			     $_SESSION['error']="<span class='error'>Image Size should be less then 2MB!
			     </span>";
			     return;
			    } elseif (in_array($file_ext, $permited) === false) {
			     $_SESSION['error']="<span class='error'>You can upload only:-"
			     .implode(', ', $permited)."</span>";
			     return;
			 	}else{
			 		$query="select * from users where id='$user_id'";
			        $qresult=$this->db->select($query);
			        if ($qresult) {
			        $result=$qresult->fetch_assoc();
			        $img=$result['user_img'];
			        unlink($img);
			        }
			 	move_uploaded_file($file_temp, $uploaded_image);
			    $query="update users 
					    set
					    name   	  	   ='$name',
					    user_img       ='$uploaded_image'
					    where id =$user_id";

				$userUpdate=$this->db->update($query);
			    Session::set("name",$name);
			    Session::set("image",$uploaded_image);
			 	}
			if ($userUpdate) {
				$_SESSION['success']="<span class='success'>User data update successfully</span>";
				return $this->redirect();
			}else{
				$_SESSION['error']="<span class='error'>User data  not update .</span>";
				return $this->redirect();
			}

		}
	public function changePassword($data)
	{

		$old_pass=$this->fm->validation($data['old-pass']);
       $new_pass=$this->fm->validation($data['new-pass']);
        $old_pass=mysqli_real_escape_string($this->db->link,$old_pass);
        $new_pass=mysqli_real_escape_string($this->db->link,$new_pass);
	 if ($old_pass=="" ||$new_pass=="") {
          $_SESSION['error']= "<span class='error'> Field must not be empty </span>";
				return $this->redirect();
       }else{
       	$old=md5($old_pass);
       	$new=md5( $new_pass);
       	$adminid=Session::get("id");
        $query="select * from users where id='$adminid'";
        $result=$this->db->select($query)->fetch_assoc();
        $pass=$result['password'];
        if ($pass!=$old) {
        	$_SESSION['error']="<span class='error'>Password not match.</span>";
				return $this->redirect();
        }else{
            $query="update users
                 set
                  password='$new'
                 where id='$adminid'";
          $updated_rows = $this->db->update($query);  
          if ( $updated_rows) {
               $_SESSION['success']="<span class='success'>Password Updated successfully</span>";
				return $this->redirect();
            }else{

                $_SESSION['error']="<span class='error'>Password Not Updated .</span>";
				return $this->redirect();
            }  
        }
    }
	}
	public function getSupervisor()
	{
		$query="select * from users where role='1'";
		$result=$this->db->select($query);
		return $result;
	}
	public function contactUs($data)
	{

		$subject=$this->fm->validation($data['subject']);
		$email=$this->fm->validation($data['email']);
		$subject=mysqli_real_escape_string($this->db->link,$subject);
		$email=mysqli_real_escape_string($this->db->link,$email);
		$body=mysqli_real_escape_string($this->db->link,$data['message']);
	
	 if (empty($subject)) {
	 	$_SESSION['error']="<span class='error'>Subject must not be empty</span>";
		return $this->redirect();
	 }elseif (empty($email)) {
	 	$_SESSION['error']="<span class='error'>subject must not be empty</span>";
		return $this->redirect();
	 }
	  $query = "INSERT INTO contact(subject,email,message)   
           VALUES('$subject','$email','$body')";  
        $inserted_rows = $this->db->insert($query); 

        if ($inserted_rows) { 
        $_SESSION['success']="<span class='error'>message send successfully</span>"; 
        }else { 
        $_SESSION['error']="<span class='error'>message not send</span>";
        return $this->redirect();  
         }
	 
	 
	}
	public function redirect()
	{
		header('Location: ' . $_SERVER['HTTP_REFERER']);
			exit;
	}
	public function getUserData($id){
		$query="select * from address where id=$id";
		$result=$this->db->select($query);
		return $result;
	}

	
}
 ?>