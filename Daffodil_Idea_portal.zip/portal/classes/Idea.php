<?php 
$filepath=realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once($filepath.'/../helpers/Format.php');
include_once ($filepath.'/../lib/Session.php');
Session::init(); 
 ?>
<?php 
class Idea{
	private $db;
	private $fm;
	public function __construct(){
		$this->db=new Database();
		$this->fm=new Format();	
	}
	public function insertIdea($data,$file)
	{

		$project_type_id=mysqli_real_escape_string($this->db->link,$data['project_type_id']);
		$user_id=mysqli_real_escape_string($this->db->link,$data['user_id']);
		$supervisor_id=mysqli_real_escape_string($this->db->link,$data['supervisor_id']);
		$name=mysqli_real_escape_string($this->db->link,$data['name']);
		$content=mysqli_real_escape_string($this->db->link,$data['content']);

		$image=mysqli_real_escape_string($this->db->link,$file['image']['name']);
		$document=mysqli_real_escape_string($this->db->link,$file['document']['name']);
		if ($project_type_id==""||$name==""||$supervisor_id==""||$content==""||$image==""||$document=="") {
			$_SESSION['error']= "<span class='error'> field must not be empty </span>";
			return ;
             }
             
            $permited  = array('jpg', 'jpeg', 'png', 'gif');
            $doucment_permited  = array('doc', 'docx', 'pdf');
			$file_name = $file['image']['name'];
			$file_size = $file['image']['size'];
			$file_temp = $file['image']['tmp_name'];
			$div = explode('.', $file_name);
			$file_ext = strtolower(end($div));
			$unique_image = uniqid() .'-'.rand(1,100).'.'.$file_ext;
			$uploaded_image = "img/upload/idea/".$unique_image;

			$document_name = $file['document']['name'];
			$document_size = $file['document']['size'];
			$document_temp = $file['document']['tmp_name'];
			$div = explode('.', $document_name);
			$document_ext = strtolower(end($div));
			$document_image = uniqid() .'-'.rand(1,100).'.'.$document_ext;
			$document_image = "img/upload/document/".$document_image;
			if ($file_size >(1048567*2)) {
			     $_SESSION['error']="<span class='error'>Image Size should be less then 2MB!
			     </span>";
			    }elseif (in_array($file_ext, $permited) === false) {
			     $_SESSION['error']="<span class='error'>You can upload image only:-"
			     .implode(', ', $permited)."</span>";

			 }
			 if ($document_size >(1048567*5)) {
			     $_SESSION['error']="<span class='error'>Document Size should be less then 5MB!
			     </span>";
			    }elseif (in_array($document_ext, $doucment_permited) === false) {
			     $_SESSION['error']="<span class='error'>You can upload document only:-"
			     .implode(', ', $doucment_permited)."</span>";

			 }else{
             	move_uploaded_file($file_temp, $uploaded_image);
             	move_uploaded_file($document_temp, $document_image);
             	$query ="INSERT INTO  ideas(project_type_id,user_id,supervisor_id,name,content,image,document)
                VALUES('$project_type_id','$user_id','$supervisor_id','$name','$content','$uploaded_image','$document_image')";

             	$UserInsert=$this->db->insert($query);
				if ($UserInsert) {
					$_SESSION['success']="<span class='success'> data insert successful plesde login</span>";
					return $this->redirect();
				}else{
					$_SESSION['error']="<span class='error'> data  not insert .</span>";
					return $this->redirect();
				}
			 	
			 }
	}
	public function getAllIdeas(){
		$uid=Session::get('id');
		$query="select * from ideas where user_id='$uid' AND status='3'";
		$result=$this->db->select($query);
		return $result;
	}
	public function getSigleIdea($id){
		$upquery="UPDATE ideas SET view=view+1 WHERE id='$id'";
   		$best=$this->db->update($upquery);
		$query="select * from ideas where id='$id'";
		$result=$this->db->select($query);
		return $result;
	}
	public function projectType(){
		$query="select * from project_types";
		$result=$this->db->select($query);
		return $result;
	}
	public function update($data,$file,$id)
	{

		$project_type_id=mysqli_real_escape_string($this->db->link,$data['project_type_id']);
		$user_id=mysqli_real_escape_string($this->db->link,$data['user_id']);
		$name=mysqli_real_escape_string($this->db->link,$data['name']);
		$content=mysqli_real_escape_string($this->db->link,$data['content']);

		$image=mysqli_real_escape_string($this->db->link,$file['image']['name']);
		$document=mysqli_real_escape_string($this->db->link,$file['document']['name']);
		
		if ($project_type_id==""||$name==""||$content=="") {
			$_SESSION['error']= "<span class='error'> field must not be empty </span>";
			return ;
             }
             $file_temp='';
             $uploaded_image='';
          	 $document_temp='';
           	$document_image='';

 			if (!empty($image)) {
        	$permited  = array('jpg', 'jpeg', 'png', 'gif');
			$file_name = $file['image']['name'];
			$file_size = $file['image']['size'];
			$file_temp = $file['image']['tmp_name'];
			$div = explode('.', $file_name);
			$file_ext = strtolower(end($div));
			$unique_image = uniqid() .'-'.rand(1,100).'.'.$file_ext;
			$uploaded_image = "img/upload/idea/".$unique_image;

			
			if ($file_size >(1048567*2)) {
			     $_SESSION['error']="<span class='error'>Image Size should be less then 2MB!
			     </span>";
			     return ;
			    }elseif (in_array($file_ext, $permited) === false) {
			     $_SESSION['error']="<span class='error'>You can upload image only:-"
			     .implode(', ', $permited)."</span>";
			     return ;

			 }
			}
			if (!empty($document)) {
            $doucment_permited  = array('doc', 'docx', 'pdf');
			 $document_name = $file['document']['name'];
			$document_size = $file['document']['size'];
			$document_temp = $file['document']['tmp_name'];
			$div = explode('.', $document_name);
			$document_ext = strtolower(end($div));
			$document_image = uniqid() .'-'.rand(1,100).'.'.$document_ext;
			$document_image = "img/upload/document/".$document_image;
			 if ($document_size >(1048567*5)) {
			     $_SESSION['error']="<span class='error'>Document Size should be less then 5MB!
			     </span>";
			     return ;
			    }elseif (in_array($document_ext, $doucment_permited) === false) {
			     $_SESSION['error']="<span class='error'>You can upload document only:-"
			     .implode(', ', $doucment_permited)."</span>";
			     return ;

			 }
			}
             $ideaupdate='';
             
         if (empty($image) && empty($document)) {
         	$query="update ideas 
				    set
				    project_type_id   ='$project_type_id',
				    user_id           ='$user_id',
				    name              ='$name',
				    content          ='$content'
				    where  id=$id";

			$ideaupdate=$this->db->update($query);
         	
         }elseif (!empty($image) && empty($document)) {
         	move_uploaded_file($file_temp, $uploaded_image);
         	$query="update ideas 
				    set
				    project_type_id   ='$project_type_id',
				    user_id           ='$user_id',
				    name              ='$name',
				    content           ='$content',
				    image             ='$uploaded_image'
				    where  id   =$id";

			$ideaupdate=$this->db->update($query);
         	
         }elseif (empty($image) && !empty($document)) {
            move_uploaded_file($document_temp, $document_image);
         	$query="update ideas 
				    set
				    project_type_id   ='$project_type_id',
				    user_id           ='$user_id',
				    name              ='$name',
				    content           ='$content',
				    document          ='$document_image'
				    where  id   =$id";

			$ideaupdate=$this->db->update($query);
         	
         }else{
         	move_uploaded_file($file_temp, $uploaded_image);
            move_uploaded_file($document_temp, $document_image);
         	$query="update ideas 
				    set
				    project_type_id   ='$project_type_id',
				    user_id           ='$user_id',
				    name              ='$name',
				    content           ='$content',
				    image             ='$uploaded_image',
				    document          ='$document_image'
				    where  id   =$id";

			$ideaupdate=$this->db->update($query);

         }

         if ($ideaupdate) {
			$_SESSION['success']="<span class='success'> data insert successful plesde login</span>";
			return $this->redirect();
		}else{
			$_SESSION['error']="<span class='error'> data  not insert .</span>";
			return $this->redirect();
		}
         
	}
	public function getAllPostIdea(){
		$query="select * from ideas where status='0' limit 10";
		$result=$this->db->select($query);
		return $result;
	}
	public function rating($id)
	{
		$uid=Session::get('id');
		$query="select * from ratings where user_id='$uid' and idea_id='$id'";
		$result=$this->db->select($query);
		if (!$result) {
		$query ="INSERT INTO  ratings(user_id,idea_id)
                VALUES('$uid','$id')";
         $this->db->insert($query);
			$upquery="UPDATE ideas SET rating=rating+1 WHERE id='$id'";
    		$best=$this->db->update($upquery);
    		if ($best) {
				$_SESSION['success']="<span class='success'> Rating added</span>";
				return $this->redirect();
			}else{
				$_SESSION['error']="<span class='error'> Rating not added</span>";
				return $this->redirect();
			}


		}else{
			$_SESSION['error']="<span class='error'> Rating Already added</span>";
				return $this->redirect();
		}
	}
	public function redirect()
	{
		header('Location: ' . $_SERVER['HTTP_REFERER']);
			exit;
	}	
	
}
 ?>