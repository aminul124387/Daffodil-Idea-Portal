<?php 
$filepath=realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once($filepath.'/../helpers/Format.php');
require_once '../vendor/autoload.php';
require 'credential.php'; 
 ?>
<?php 
class Department{
	private $db;
	private $fm;
	public function __construct(){
		$this->db=new Database();
		$this->fm=new Format();	
	}
	
	public function getDepartment(){
		$query="select * from department";
		$result=$this->db->select($query);
		return $result;
	}
	public function getStudents(){
		$query="select * from users where role='3'";
		$result=$this->db->select($query);
		return $result;
	}
	public function getSupervisor(){
		$query="select * from users where role='1'";
		$result=$this->db->select($query);
		return $result;
	}
	public function getHead(){
		$query="select * from users where role='2'";
		$result=$this->db->select($query);
		return $result;
	}
	public function addUser($data,$file){

		$name=mysqli_real_escape_string($this->db->link,$data['name']);
		$email=mysqli_real_escape_string($this->db->link,$data['email']);
		$department=mysqli_real_escape_string($this->db->link,$data['department']);
		$semister=mysqli_real_escape_string($this->db->link,$data['semister']);
		$language=mysqli_real_escape_string($this->db->link,$data['language']);
		$role=mysqli_real_escape_string($this->db->link,$data['role']);
		$typeofuser="supervisor";
		
		if ($role==2) {
			$typeofuser="department Head";
		} 
		
		if ($name==""||$email==""||$department==""||$semister==""||$language==""||$role=="") {
			var_dump($role);
			$_SESSION['error']= "<span class='error'> field must not be empty </span>";
			return $this->redirect();
             }
             if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		         $_SESSION['error']="<span class='error'>Invalid Email</span>";
		        return $this->redirect();
	        }
             $eml="select * from users where email='$email' limit 1";
             $emlcheck=$this->db->select($eml);
             if ($emlcheck <> false){
             	$_SESSION['error']="<span class='error'>Email  already exist !</span>";
				return $this->redirect();
             }

            $rand=rand(10000,99999);
		    $newpass=$rand;
		    $pass=md5($newpass);
		    $subject="your password";
            $message="Your name is " .$name.  " and Password "  .$newpass.  " plz visit website to login.";
            // Create the Transport
            $transport = (new Swift_SmtpTransport('smtp.gmail.com', 587,'tls'))
              ->setUsername(EMAIL)
              ->setPassword(PASS)
            ;

            // Create the Mailer using your created Transport
            $mailer = new Swift_Mailer($transport);

            // Create a message
            $message = (new Swift_Message($subject))
              ->setFrom([EMAIL => 'New password'])
              ->setTo([$email])
              ->setBody($message)
              ;
            // Send the message
            $result = $mailer->send($message);
            if(!$result) {
            $_SESSION['error']="<span class='error'>Message could not be sent.Try again</span>";
       		return $this->redirect();
            }else{
             
             	$query ="INSERT INTO users(name,email,department,semister,password,language,types,role)
                VALUES('$name','$email','$department','$semister','$pass','$language', '$typeofuser','$role')";

             	$UserInsert=$this->db->insert($query);
				if ($UserInsert) {
					$_SESSION['success']="<span class='success'>user data insert successful plesde login</span>";
					return $this->redirect();
				}else{
					$_SESSION['error']="<span class='error'>user data  not insert .</span>";
					return $this->redirect();
				}
			}
	}
	public function redirect()
	{
		header('Location: ' . $_SERVER['HTTP_REFERER']);
			exit;
	}

}
 ?>