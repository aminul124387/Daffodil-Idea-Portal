<?php include('inc/header1.php'); ?>
<?php 
include 'lib/Session.php'; 
Session::init();
include('classes/User.php') ;
$user=new User();
if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['passwordRecovery'])) {
 $userReg=$user->passRecovery($_POST);
   }
 ?>
<body>
<div id="loginideaportal">
  <div class="container">
   <div class="row">
    <div class="col-xs-12 col-md-12 col-md-offset-5">
      <img src="img/team/02.jpg" class="img-circle" alt="Profile image"/>
     </div>
      
      <div class="col-xs-12 col-md-8 col-md-offset-4">
          <p style="color:black;font-size:23px;padding-left:50px;margin-bottom:10px;"> Reset your password</p>
         
      </div>
      
      <div class="col-xs-12 col-md-4 col-md-offset-4">
        <?php if(isset($_SESSION['error'])) {?>
          <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong style="color: red;">Warning!</strong>
               <?php echo($_SESSION['error']);

               unset($_SESSION['error']);
               ?>
          </div>
        <?php }?>
        <?php if(isset($_SESSION['success'])) {?>
        <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong style="color: green;">Success!</strong> 
            <?php echo($_SESSION['success']);

               unset($_SESSION['success']);
               ?>
          </div>
        <?php }?>
        </div>
   
      <div class="col-xs-12 col-md-4 col-md-offset-4">
         <form class="form_design" action="" method="post">
            <div class="form-group">
              <label style="font-weight:bold;color:black;" for="inputUserName">Enter your email address and we will send you a link to reset your password.</label>
              <input class="form-control" placeholder="Please Enter your name" type="email" id="inputUserName" required="required" name="email" />
             </div> 
             
             <button type="submit" class="btn custombutton" name="passwordRecovery">Send password reset email</button>
          </form>
       </div>
       </div>
     </div>
     <br/>
<?php include('inc/footer1.php'); ?>