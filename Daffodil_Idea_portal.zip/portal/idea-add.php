<?php include("inc/header.php"); ?>
<?php 
include("classes/Idea.php");
include("classes/User.php");
$idea= new Idea();
$user= new User();
 if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['idea'])) {
   $userLog=$idea->insertIdea($_POST,$_FILES);
     }
 ?>
        <!-- About Section -->
        <div class="contribute">
            
            <div class="container">
                
                <div class="row">
                    
                    <div class="col-md-12">
<?php include('inc/sidebar.php') ;?>
                        
                        
                        <div class="col-md-8">
                            
                            <div class="row">
                                <div class="col-xs-12">
                                    <h3 style="text-align:center;margin-bottom:30px;font-weight:bold;">Submit Your project Idea</h3>
                                    <?php if(isset($_SESSION['error'])) {?>
                                  <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                      <strong style="color: red;">Warning!</strong>
                                       <?php echo($_SESSION['error']);

                                       unset($_SESSION['error']);
                                       ?>
                                  </div>
                                <?php }?>
                                <?php if(isset($_SESSION['success'])) {?>
                                <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <strong style="color: green;">Success!</strong> 
                                    <?php echo($_SESSION['success']);

                                       unset($_SESSION['success']);
                                       ?>
                                  </div>
                                <?php }?>
                                    <form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Project Category</label>
                                                <div class="col-sm-9">
                                                  <select class="form-control designalignment" id="sel1" name="project_type_id">
                                                    <option value=" ">Select Project Type</option>
                                                     <?php 
                                                    $types=$idea->projectType();
                                                    if ($types) {
                                                       while ($type=$types->fetch_assoc()) {
                                                     ?>
                                                    <option value="<?php echo($type['id']); ?>"><?php echo($type['name']); ?></option>
                                                  <?php }} ?>
                                                  </select>
                                                </div>
                                               </div>
                                              <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Select Supervisor</label>
                                                <div class="col-sm-9">
                                                  <select class="form-control designalignment" id="sel1" name="supervisor_id">
                                                    <option value=" ">Select Supervisor</option>
                                                    <?php 
                                                  $getspr=$user->getSupervisor();
                                                  if ($getspr) {
                                                     while ($gets=$getspr->fetch_assoc()) {
                                                   ?>
                                                    <option value="<?php echo($gets['id']);?>"><?php echo($gets['name']);?></option>
                                                   <?php }} ?>
                                                  </select>
                                                </div>
                                               </div>
                                              <input type="hidden" value="<?php echo(Session::get('id'));?>" name="user_id">
                                              <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Project Title</label>
                                                <div class="col-sm-9">
                                                  <input type="text" class="form-control" placeholder="Project Title"  name="name" >
                                                </div>
                                              </div>

                                              <div class="form-group">
                                                    <label class="control-label col-sm-3 design" for="email">Project Image</label>
                                                <div class="col-sm-9">
                                                  <input type="file" class="form-control"  placeholder="Upload Image" name="image">
                                                </div>
                                              </div>
                                              <div class="form-group">
                                                    <label class="control-label col-sm-3 design" for="email">Project Document</label>
                                                <div class="col-sm-9">
                                                  <input type="file" class="form-control"  placeholder="Upload project doument" name="document">
                                                </div>
                                              </div>
                                              <div class="form-group">
                                                <label class="control-label col-sm-3 design" for="email">Project Description</label>
                                                <div class="col-sm-9">
                                                    <textarea class="form-control" rows="5" id="comment" name="content"></textarea>
                                                </div>
                                              </div>
                                            
                                            
                                            <div class="form-group">
                                              <div class="col-sm-offset-3 col-sm-9">
                                                <button type="submit" class="btn btn-primary" name="idea">Submit</button>
                                                <button type="submit" class="btn btn-primary">Cancel</button>
                                              </div>
                                            </div>
                                          </form>
                                 </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    


<?php include("inc/footer.php"); ?>
  