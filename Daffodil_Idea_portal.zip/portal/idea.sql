-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 31, 2019 at 04:23 PM
-- Server version: 5.7.26
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idea`
--

-- --------------------------------------------------------

--
-- Table structure for table `announce`
--

DROP TABLE IF EXISTS `announce`;
CREATE TABLE IF NOT EXISTS `announce` (
  `Ann_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ann_Title` varchar(100) NOT NULL,
  `Ann_Des` varchar(100) NOT NULL,
  `Ann_Date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Ann_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announce`
--

INSERT INTO `announce` (`Ann_ID`, `Ann_Title`, `Ann_Des`, `Ann_Date`) VALUES
(7, 'f', 'f', '2019-12-27 09:52:59');

-- --------------------------------------------------------

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
CREATE TABLE IF NOT EXISTS `award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `awardname` varchar(255) NOT NULL,
  `awarddes` varchar(255) NOT NULL,
  `awardTypeName` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `award`
--

INSERT INTO `award` (`id`, `awardname`, `awarddes`, `awardTypeName`) VALUES
(1, 'Daffodil ICT Carnival Award 2019', 'Hellow', 'ICT Carnival');

-- --------------------------------------------------------

--
-- Table structure for table `awardtype`
--

DROP TABLE IF EXISTS `awardtype`;
CREATE TABLE IF NOT EXISTS `awardtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `awardtypename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `awardtype`
--

INSERT INTO `awardtype` (`id`, `awardtypename`) VALUES
(2, 'Basis soft Expo'),
(3, 'ICT Carnival'),
(4, 'ICT DIVISION');

-- --------------------------------------------------------

--
-- Table structure for table `bestproject`
--

DROP TABLE IF EXISTS `bestproject`;
CREATE TABLE IF NOT EXISTS `bestproject` (
  `BP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Project_Des` varchar(255) NOT NULL,
  `AwardType` varchar(100) NOT NULL,
  `AwardDes` varchar(255) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Team_Members` varchar(255) NOT NULL,
  PRIMARY KEY (`BP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `subject`, `email`, `message`) VALUES
(1, 'Test Mail with attachment', 'mahmud@gmail.com', 'zcsdfdsf s'),
(2, 'Test Mail with attachment', 'mahmud@gmail.com', 'sadas '),
(3, 'Test Mail with attachmentfgdfsgs', 'ujjalbhuiyan123@gmail.com', 'zczczczx zc'),
(4, 'test mail in php', 'admin@gmail.com', 'xxcv');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_cd` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `name_cd`) VALUES
(1, 'CSE', '1'),
(2, 'CIS', '2'),
(4, 'Software', '3'),
(5, 'Multimedia', '4');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
CREATE TABLE IF NOT EXISTS `feedbacks` (
  `feedback_id` int(10) NOT NULL AUTO_INCREMENT,
  `idea_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `feedback` varchar(200) DEFAULT NULL,
  `c_date` varchar(30) DEFAULT '',
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `head_super_message`
--

DROP TABLE IF EXISTS `head_super_message`;
CREATE TABLE IF NOT EXISTS `head_super_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor_id` int(10) NOT NULL,
  `head_id` int(10) DEFAULT NULL,
  `comment` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `message_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ideas`
--

DROP TABLE IF EXISTS `ideas`;
CREATE TABLE IF NOT EXISTS `ideas` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `document` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `view` tinyint(4) DEFAULT '0',
  `rating` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ideas_name_unique` (`name`),
  KEY `ideas_project_type_id_foreign` (`project_type_id`),
  KEY `ideas_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ideas`
--

INSERT INTO `ideas` (`id`, `project_type_id`, `user_id`, `supervisor_id`, `name`, `image`, `content`, `document`, `feedback`, `status`, `view`, `rating`, `created_at`, `updated_at`) VALUES
(1, 1, 6, NULL, 'electro service', 'img/upload/idea/5e0855912234e-56.jpg', 'sfsdfsd sdff', 'img/upload/document/5e0855912235d-93.pdf', NULL, 3, 26, 1, '2019-12-27 21:35:45', NULL),
(2, 1, 11, NULL, 'bakary', 'img/upload/idea/5e067a0aa9298-9.png', 'sfsdfsd sdff', 'img/upload/document/5e06793171252-32.pdf', NULL, 0, 7, 1, '2019-12-27 21:35:45', NULL),
(3, 1, 50, 12, 'Helping hand', 'img/upload/idea/5e07d579d966a-31.png', 'jk', 'img/upload/document/5e07d579d9677-42.pdf', NULL, 0, 1, 1, '2019-12-28 22:21:45', NULL),
(4, 1, 13, 13, 'DIU Hostle management system', 'img/upload/idea/5e0822d492824-7.jpg', 'sfdsf sfdf sd', 'img/upload/document/5e0822d492853-36.pdf', NULL, -1, 1, 0, '2019-12-29 03:51:48', NULL),
(5, 1, 6, NULL, 'DIU Hostel Management', 'img/upload/idea/5e067a0aa9298-9.png', 'This project about DIU Hostel.', 'img/upload/document/5e06793171252-32.pdf', NULL, 3, 18, 1, '2019-12-27 21:35:45', NULL),
(6, 2, 12, NULL, 'Auction Management System', 'img/upload/idea/5e067a0aa9298-9.png', 'This project about DIU Hostel.', 'img/upload/document/5e06793171252-32.pdf', NULL, 0, 18, 1, '2019-12-27 21:35:45', NULL),
(7, 2, 14, NULL, 'DIU Donation', 'img/upload/idea/5e067a0aa9298-9.png', 'This project about DIU Hostel.', 'img/upload/document/5e06793171252-32.pdf', NULL, 0, 18, 1, '2019-12-27 21:35:45', NULL),
(8, 3, 6, 15, 'Autonomous Cycle', 'img/upload/idea/5e084c7b2735e-49.jpg', 'autonomous car', 'img/upload/document/5e084c7b2736a-6.docx', NULL, 0, 0, 0, '2019-12-29 06:49:31', NULL),
(9, 4, 6, 12, 'Islamic Games', 'img/upload/idea/5e08536377b86-51.jpg', 'This game in ActionScript', 'img/upload/document/5e08536377be7-34.pdf', NULL, 0, 0, 0, '2019-12-29 07:18:59', NULL),
(10, 2, 6, 15, 'hotel management system', 'img/upload/idea/5e08557d7cf3e-23.jpg', 'hotel management', 'img/upload/document/5e08557d7cf4b-86.pdf', NULL, 0, 0, 0, '2019-12-29 07:27:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `Message_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Comment` varchar(255) NOT NULL,
  `Status` tinyint(4) NOT NULL,
  `message_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Message_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `noticeboard`
--

DROP TABLE IF EXISTS `noticeboard`;
CREATE TABLE IF NOT EXISTS `noticeboard` (
  `Notice_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Des` varchar(255) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Notice_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `noticeboard`
--

INSERT INTO `noticeboard` (`Notice_ID`, `Title`, `Des`, `Date`) VALUES
(1, 'd', 'd', '2019-12-27 09:53:17');

-- --------------------------------------------------------

--
-- Table structure for table `project_types`
--

DROP TABLE IF EXISTS `project_types`;
CREATE TABLE IF NOT EXISTS `project_types` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_types_name_unique` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_types`
--

INSERT INTO `project_types` (`id`, `name`) VALUES
(1, 'Android'),
(2, 'Web App'),
(3, 'Rorotics'),
(5, 'game');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `idea_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `user_id`, `idea_id`) VALUES
(1, 6, 1),
(2, 6, 3),
(3, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `super_student_message`
--

DROP TABLE IF EXISTS `super_student_message`;
CREATE TABLE IF NOT EXISTS `super_student_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor_id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `comment` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `message_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `super_student_message`
--

INSERT INTO `super_student_message` (`message_id`, `supervisor_id`, `user_id`, `comment`, `status`, `message_date`) VALUES
(6, 3, 6, 'hh', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `technology`
--

DROP TABLE IF EXISTS `technology`;
CREATE TABLE IF NOT EXISTS `technology` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `technologyname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `technology`
--

INSERT INTO `technology` (`id`, `technologyname`) VALUES
(3, 'php'),
(4, 'java');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` tinyint(4) NOT NULL DEFAULT '0',
  `semister` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_img` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'storage/app/public/profile/user.png',
  `types` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'student',
  `role` tinyint(4) NOT NULL DEFAULT '3',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `student_id`, `department`, `semister`, `password`, `language`, `image`, `user_img`, `types`, `role`, `created_at`) VALUES
(1, 'Admin', 'admin@diu.edu.bd', '', 1, 'Fall', '202cb962ac59075b964b07152d234b70', 'Php,Laravel,Bootstrap,java', 'public/user/img/img_5e00a6168df807.6226528780.jpg', 'img/upload/user.png', 'Admin', 0, '2019-12-23 05:33:42'),
(6, 'aminul', 'aminul@diu.edu.bd', '', 2, 'Spring', '81dc9bdb52d04dc20036dbd8313ed055', 'Php,Laravel,Bootstrap', 'img/upload/user.png', 'img/upload/user/5e085544e5743-99.jpg', 'student', 3, '2019-12-26 15:47:20'),
(11, 'rakib', 'mahmud@diu.edu.bd', '', 2, 'summar', '202cb962ac59075b964b07152d234b70', 'Php,Laravel,Bootstrap', 'img/upload/5e07a94a32cb7-20.png', 'img/upload/user/5e08254bc6b40-29.png', 'student', 3, '2019-12-28 19:13:14'),
(12, 'khaledd', 'khaled@diu.edu.bd', '181-16-309', 2, 'summar', '202cb962ac59075b964b07152d234b70', 'Php,Laravel,Bootstrap,css', 'img/upload/5e07c050c7d03-21.png', 'storage/app/public/profile/user.png', 'supervisor', 1, '2019-12-28 20:51:28'),
(13, 'Rafi haq', 'rafi@diu.edu.bd', '', 2, 'summar', '202cb962ac59075b964b07152d234b70', 'Php,Laravel,Bootstrap,css', 'img/upload/5e07c050c7d03-21.png', 'storage/app/public/profile/user.png', 'supervisor', 1, '2019-12-28 20:51:28'),
(14, 'alauddin', 'alauddn@diu.edu.bd', NULL, 1, 'summar', '202cb962ac59075b964b07152d234b70', 'Php,Laravel,Bootstrap', NULL, 'storage/app/public/profile/user.png', 'department Head', 2, '2019-12-29 04:08:49'),
(15, 'Naima Rahman', 'naimaRahman@diu.edu.bd', '', 2, 'Spring', '202cb962ac59075b964b07152d234b70', 'JAVA, Android', 'img/upload/5e07a94a32cb7-20.png', 'img/upload/user/5e08254bc6b40-29.png', 'supervisor', 1, '2019-12-28 19:13:14'),
(16, 'Akterur ', 'akter@diu.edu.bd', NULL, 1, 'summer', '202cb962ac59075b964b07152d234b70', 'Php,Laravel,Bootstrap', NULL, 'storage/app/public/profile/user.png', 'department Head', 2, '2019-12-29 04:08:49'),
(17, 'Towhid Buiyan', 'towhid@diu.edu.bd', NULL, 3, 'summer', '202cb962ac59075b964b07152d234b70', 'SDLC, JAVA', NULL, 'storage/app/public/profile/user.png', 'department Head', 2, '2019-12-29 04:08:49'),
(18, 'Sarwar Mollah', 'sarwar@diu.edu.bd', NULL, 2, 'Fall', '202cb962ac59075b964b07152d234b70', 'SDLC, Network Security', NULL, 'storage/app/public/profile/user.png', 'department Head', 2, '2019-12-29 04:08:49');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
