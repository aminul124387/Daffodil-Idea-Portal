<?php include('inc/header1.php') ?>
<?php
include('classes/User.php') ;
$user=new User();
  if ($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['login'])) {
   $userLog=$user->userLogin($_POST);
     }
  ?>
<body>
<!-- Navigation -->

    
    

<!-- About Section -->
<div id="loginideaportal">
  <div class="container">
   <div class="row">
    <div class="col-xs-12 col-md-12 col-md-offset-5">
      <img src="img/team/02.jpg" class="img-circle" alt="Profile image"/>
     </div>
      
      <div class="col-xs-12 col-md-8 col-md-offset-4">
          <p style="color:black;font-size:23px;padding-left:50px;margin-bottom:10px;">Sign in to DIU Idea Portal</p>
      </div>
      
      <div class="col-xs-12 col-md-4 col-md-offset-4">
         <?php if(isset($_SESSION['error'])) {?>
          <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong style="color: red;">Warning!</strong>
               <?php echo($_SESSION['error']);

               unset($_SESSION['error']);
               ?>
          </div>
        <?php }?>
        <?php if(isset($_SESSION['success'])) {?>
        <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong style="color: green;">Success!</strong> 
            <?php echo($_SESSION['success']);

               unset($_SESSION['success']);
               ?>
          </div>
        <?php }?>
        </div>
   
      <div class="col-xs-12 col-md-4 col-md-offset-4">
         <form action="" method="post" class="form_design">
            <div class="form-group">
              <label style="font-weight:bold;color:black;" for="inputUserName">Username or email address</label>
              <input class="form-control" placeholder="Please Enter your Email" type="email" id="inputUserName" name="email"/>
             </div> 
             <div class="forgotpassword">
               <a href="password-forget.php">Forgot password?</a>
             </div>
             <div class="form-group">
               <label style="font-weight:bold;color:black;" for="inputPassword">Password</label>
              <input class="form-control" placeholder="Please Enter your Password" type="password" id="inputPassword" name="password"/>
             </div>
             <button type="submit" class="btn custombutton"  name="login">Sign in</button>
          </form>
       </div>
       </div>
     </div>
     <br/>
     
   
     
          <div class="container">
               <div class="row">
                <div class="col-xs-12 col-md-4 col-md-offset-4">
                        <div class="well well-sm">
                        <p style="color:black;text-align:center;margin-top:7px;">New to DIU Idea Portal?<a style="color:#0366D6;" href="reg.php"> Create an account.</a></p>
                       </div>
                </div>
                </div>
            </div>
            
<?php include('inc/footer1.php') ?>