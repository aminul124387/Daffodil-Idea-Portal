﻿<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>

<!-- top navigation -->
<?php
	include('inc/navbar.php');
?>
<?php
	$countIdeas="0";
	$countStudent="0";
	$countSupervisor="0";
	$countAwardproject="0";
	$countAcceptIdea="0";
	$countTotalDepartment="0";
	
	$sql = "SELECT * FROM ideas";
	$query = $db->select($sql);
	if($query){
		$countIdeas = $query->num_rows;
		}else{
		$countIdeas="0";
	}
	
	//
	
	$sql = "SELECT * FROM users where role='3'";
	$query1 = $db->select($sql);
	if($query1){
		$countStudent = $query1->num_rows;
		}else{
		$countStudent="0";
	}
	
	//
	
	$sql = "SELECT * FROM users where role='1'";
	$query2 = $db->select($sql);
	if($query2){
		$countSupervisor = $query2->num_rows;
		}else{
		$countSupervisor="0";
	}
	
	//
	$sql = "SELECT * FROM users where role='1'";
	$query3 = $db->select($sql);
	if($query3){
		$countAwardproject = $query3->num_rows;
		}else{
		$countAwardproject="0";
	}
	
	//
	
	$sql = "SELECT * FROM award";
	$query4 = $db->select($sql);
	if($query4){
		$countAcceptIdea = $query4->num_rows;
		}else{
		$countAcceptIdea="0";
	}
	
	//
	
	$sql = "SELECT * FROM department";
	$query5 = $db->select($sql);
	if($query5){
		$countTotalDepartment = $query5->num_rows;
		}else{
		$countTotalDepartment="0";
	}
?>

<!-- /top navigation -->

<!-- page content -->
<div class="right_col" role="main">
	<!-- top tiles -->
	<div class="row" style="display: inline-block;" >
		<div class="tile_count">
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<span class="count_top"><i class="fa fa-user"></i> Total Ideas</span>
				<div class="count"><?php echo $countIdeas;?></div>
				
			</div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<span class="count_top"><i class="fa fa-clock-o"></i> Total Students</span>
				<div class="count"><?php echo $countStudent;?></div>
				
			</div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<span class="count_top"><i class="fa fa-user"></i> Total Supervisors</span>
				<div class="count"><?php echo $countSupervisor;?></div>
				
			</div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<span class="count_top"><i class="fa fa-user"></i> Awarded Projects</span>
				<div class="count"><?php echo $countAwardproject;?></div>
				
			</div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<span class="count_top"><i class="fa fa-user"></i> Accepted Idea</span>
				<div class="count"><?php echo $countAcceptIdea;?></div>
			</div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<span class="count_top"><i class="fa fa-user"></i> Total Department</span>
				<div class="count"><?php echo $countTotalDepartment;?></div>
				<div>
				</div>
			</div>
			<!-- /top tiles -->
			
			<div class="row">
				<div class="col-md-12 col-sm-12 ">
					<div class="dashboard_graph">
						
						<div class="row x_title">
							<div class="col-md-6">
								<h3>Graphical Representation <small> of DIU IDEA PORTAL</small></h3>
							</div>
							<div class="col-md-6">
								<div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
									<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
									<span>December 30, 2014 - January 28, 2015</span> <b class="caret"></b>
								</div>
							</div>
						</div>
						
						<div class="col-md-12 col-sm-12 ">
							
							
							<div class="col-md-4">
								<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
								<script type="text/javascript">  
									google.charts.load('current', {'packages':['corechart']});  
									google.charts.setOnLoadCallback(drawChart);  
									
									function drawChart()  
									{  
										var data = google.visualization.arrayToDataTable([  
										['Gender', 'Number'],  
										<?php 
											$aa='<div>Brand : <b>$row["productName"]</b><br/>Total Revenue : <b></div>';
											$query = "SELECT * FROM ideas GROUP BY status";
											$msg=$db->select($query);
											$ss="";
											if ($msg) {
												while ($result=$msg->fetch_assoc()) {
													$ss=$result["id"];
													$pp='';
													$po='';
													$dd='';
													if ($result["status"]==0) {
														$pp='Pending';
													echo "['Pending ',".$ss."],";

													}elseif($result["status"]==2){
														$po='Processing';
													echo "['Processing',".$ss."],";

													}elseif($result["status"]==3){
													echo "['Accepted',".$ss."],";

													}else{
														echo "['Rejected',".$ss."],";
													}

												}
												
											}
											
										?>
										
										]);  
										var options = {  
											title: 'Percentage of Accepted Project',  
											is3D:true,  
											// pieHole: 0.4  
										};  
										var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
										chart.draw(data, options);  
									}  
								</script>  
								<div id="piechart" style="width:320px; height: 200px;"></div>
								
							</div>
							
							<div class="col-md-4">
								
								<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
								<script type="text/javascript">  
									google.charts.load('current', {'packages':['corechart']});  
									google.charts.setOnLoadCallback(drawChart);  
									
									function drawChart()  
									{  
										var data = google.visualization.arrayToDataTable([  
										['Gender', 'Number'],  
										<?php 
											
											$query = "SELECT * FROM awardtype";
											$msg=$db->select($query);
											$ss="";
											$dd="";
											if ($msg) {
												while ($result=$msg->fetch_assoc()) {
													$ss=$result["id"];
													$dd=$result["awardtypename"];
													echo "['M :".$dd."',".$ss."],";
												}
												
											}
											
										?>
										
										]);  
										var options = {  
											title: 'Project Award Type',  
											is3D:true,  
											// pieHole: 0.4  
										};  
										var chart = new google.visualization.PieChart(document.getElementById('pie'));  
										chart.draw(data, options);  
									}  
								</script>  
								<div id="pie" style="width: 320px; height: 200px;"></div>
							</div>
							
							
							<div class="col-md-4">
								
								<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
								<script type="text/javascript">  
									google.charts.load('current', {'packages':['corechart']});  
									google.charts.setOnLoadCallback(drawChart);  
									
									function drawChart()  
									{  
										var data = google.visualization.arrayToDataTable([  
										['Gender', 'Number'],  
										<?php 
											
											$query = "SELECT * FROM project_types";
											$msg=$db->select($query);
											$ss="";
											$dd="";
											if ($msg) {
												while ($result=$msg->fetch_assoc()) {
													$ss=$result["id"];
													$dd=$result["name"];
													echo "['M :".$dd."',".$ss."],";
												}
												
											}
											
										?>
										
										]);  
										var options = {  
											title: 'Project Type',  
											is3D:true,  
											// pieHole: 0.4  
										};  
										var chart = new google.visualization.PieChart(document.getElementById('pie1'));  
										chart.draw(data, options);  
									}  
								</script>  
								<div id="pie1" style="width: 320px; height: 200px;"></div>
							</div>
							
						</div>
						
						
						
						<div class="col-md-12">
							<h3 style="text-align:center;font-style:bold;color:#2769A1;">*** Project IDEA For Departments ***</h3>
							<div class="col-md-12">
								
								
								<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
								<script type="text/javascript">  
									
									google.charts.load("visualization","1", {packages:['corechart']});		   
									google.charts.setOnLoadCallback(drawChart);  
									
									function drawChart()  
									{  
										var data = google.visualization.arrayToDataTable([  
										['Gender', 'Project Number'],  
										<?php 
											
											$query = "SELECT department.name, COUNT(users.department) as 'Project Number' From users, department where users.department = department.id GROUP BY users.department";
											$msg=$db->select($query);
											$ss="";
											$dd="";
											if ($msg) {
												while ($result=$msg->fetch_assoc()) {
													$ss=$result["Project Number"];
													$dd=$result["name"];
													echo "['Department:".$dd."',".$ss."],";
												}
											}
										?>
										]);
										var options = {  
											title: 'Number of Projects for each Department',  
											is3D:true,  
											// pieHole: 0.4  
										};  
										var chart = new google.visualization.ColumnChart(document.getElementById('java'));  
										chart.draw(data, options);  
									}  
								</script>  
								<div id="java" style="width:920px; height:400px;"></div>
								
							</div>
							
						</div>
						
					</div>
				</div>
			</div>
			
			<?php
				include('inc/footer.php');
			?>							