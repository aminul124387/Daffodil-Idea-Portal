

<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>

<!-- top navigation -->
<?php
	include('inc/navbar.php');
?>

<?php 
	if (isset($_GET['delid'])) {
		$delid=$_GET['delid'];
		$delquery="delete from ideas where BP_ID='$delid'";
		$deldmsg=$db->delete($delquery);
	}
?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		
		<div class="clearfix"></div>
		
		<div class="col-md-12 col-sm-12">
			
			
			<div class="x_panel">
				<div class="x_title">
                    <h2>Table design <small>Custom design</small></h2>
					<div class="clearfix"></div>
				</div>
				<div class="x_content>
				<div class="table-responsive">
					<a href="report/reportIdeaList.php"  class="btn btn-success" name="btnNotice">Print</a>
					<table class="table table-striped jambo_table bulk_action">
						<thead>
							<tr class="headings">
								<th class="column-title">Project Type Id </th>
								<th class="column-title">User Id </th>
								<th class="column-title">Name </th>
								<th class="column-title">Image</th>
								<th class="column-title no-link last"><span class="nobr">Action</span>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr class="odd pointer">
								<?php 
									$query="select * from ideas";
									$msg=$db->select($query);
									$i=0;
									if ($msg) {
										while ($result=$msg->fetch_assoc()) {
											$i++;	
										?>
										<td class=" "><?php echo($result['project_type_id']);?></td>
										<td class=" "><?php echo($result['user_id']);?></td>
										<td class=" "><?php echo($result['name']);?></td>
										<td class=" "><?php echo($result['image']);?></td>
										
										<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delid=<?php echo($result['id']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
											
											<a href="?update=<?php echo($result['id']); ?>"><span style="color:green;font-size:19px;margin-left:10px;" class="glyphicon glyphicon-pencil"></span></a>
										</td>
									</tr>
								<?php } } ?>
								
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

</div>

</div>
</div>


<?php
	include('inc/footer.php');
?>	
