
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>

<?php
	include_once'../classes/Department.php';
	$department=new Department();
	include('inc/navbar.php');
?>

<div class="right_col" role="main">
	<div class="">
		
		<div class="clearfix"></div>
		
		<div class="col-md-12 col-sm-12  ">
			<div class="x_panel">
				<div class="x_title">
                    <h2>User Table <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
						<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
						</li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
							
						</li>
						<li><a><i class="fa fa-close"></i></a>
						</li>
					</ul>
                    <div class="clearfix"></div>
				</div>
				
				<div class="x_content">
					<a href="report/reportStudentList.php"  class="btn btn-success" name="btnNotice">Print</a>
                    <div class="table-responsive">
						<table class="table table-striped jambo_table bulk_action">
							<thead>
								<tr class="headings">
									<th class="column-title">Name </th>
									<th class="column-title">Email</th>
									<th class="column-title">Department </th>
									<th class="column-title">Semister</th>
									<th class="column-title">Language </th>
									<th class="column-title">Type </th>
									<th class="column-title no-link last"><span class="nobr">Action</span>
									</th>
									<th class="bulk-actions" colspan="7">
										<a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt"> </span> ) <i class="fa fa-chevron-down"></i></a>
									</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$students=$department->getStudents();
									if ($students) {
										while ($student=$students->fetch_assoc()) {
										?>
										<tr class="even pointer">
											<td class=" "><?php echo($student['name']);?></td>
											<td class=" "><?php echo($student['email']);?></td>
											<?php 
												$deptt=$department->getDepartment();
												if ($deptt) {
													while ($dpt=$deptt->fetch_assoc()) {
														if ($student['department']==$dpt['id']) {
															
														?>
														<td class=" "><?php echo($dpt['name']);?></td>
													<?php } ?>
												<?php }}else{?>
												<td class=" ">N/A</td>
											<?php } ?>
											<td class=" "><?php echo($student['semister']);?></td>
											<td class=" "><?php echo($student['language']);?></td>
											<td class="a-right a-right "><?php echo($student['types']);?></td>
											<td class=" last"><a href="#">View</a>
											</td>
										</tr>
									<?php }} ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
?>	
