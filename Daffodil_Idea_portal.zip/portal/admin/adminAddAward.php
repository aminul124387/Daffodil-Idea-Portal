

<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	$db=new Database();
?>


<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btnNotice'])) {
		
		$awardtype=$fm->validation($_POST['awardtype']);
		$des=$fm->validation($_POST['des']);
		$awardname=$fm->validation($_POST['awardname']);
		
		$awardtype=mysqli_real_escape_string($db->link,$awardtype);
		$des=mysqli_real_escape_string($db->link,$des);
		$awardname=mysqli_real_escape_string($db->link,$awardname);
		
		
		if (empty($awardtype)) {
			
			$error="Award Type name field must not be empty!!";
			
			}else if($awardtype == -1){
			
			$error="Award Type name field must not be empty!!";
			
			}elseif(empty($des)){
			
			$error="Description field must not be empty!!";
			
			}elseif(empty($awardname)){
			
			$error="Award name field must not be empty!!";
			
			}else{
			
			$mailquery="select * from award where awardname='$awardname' limit 1";
			$namecheck=$db->select($mailquery);
			
			if ($namecheck <> false) {
				
             	$error="Sorry!Award Name Already Exit!!";
				
				}else{
				
				$query = "INSERT INTO award(awardname,awarddes,awardTypeName)   
				VALUES('$awardname','$des','$awardtype')";  
				$inserted_rows = $db->insert($query);    
				if ($inserted_rows) {  
					$msg="Add Award Name!!" ;  
					}else {   
					$error="Something is wrong!!!" ;  
				}
			}
		}
	}
	
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<?php 
			if (isset($_GET['delid'])) {
				$delid=$_GET['delid'];
				$delquery="delete from award where id='$delid'";
				$deldmsg=$db->delete($delquery);
			}
		?>
		<div class="page-title">
			<div class="title_left">
                <h3>Award</h3>
			</div>
			
			<div class="title_right">
                <div class="col-md-5 col-sm-5  form-group pull-right top_search">
					<div class="input-group">
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 ">
			<div class="x_panel">
				<div class="x_title">
                    <h2>Add Award <small>different form elements</small></h2>
                    <div class="clearfix"></div>
				</div>
				<div class="x_content">
                    <br />
					<?php 
						if (isset($error)) {
							
						?>
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Alert!</strong> <?php echo $error;?>
						</div>
						
					<?php } ?>
					
					<?php 
						if (isset($msg)) {
							
						?>
						<div class="alert alert-success alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Success!</strong> <?php echo $msg;?>
						</div>
						
					<?php } ?>
					
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="" method="post">
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Award Name <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="awardname" required="required" class="form-control ">
							</div>
						</div>
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Award Description<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<textarea class="form-control" rows="5" name="des" required></textarea>
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Award Type<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								
								<select class="form-control" name="awardtype">
									<option value="-1">select Award Type</option>
									<?php 
										$query="select * from awardtype";
										$msg=$db->select($query);
										$i=0;
										if ($msg) {
											while ($result=$msg->fetch_assoc()) {
												$i++;	
											?>
											<option value="<?php echo($result['awardtypename']);?>"><?php echo($result['awardtypename']);?></option>
										<?php } } ?>
								</select>
								
							</div>
						</div>
						
						
						<div class="item form-group">
							<div class="col-md-6 col-sm-6 offset-md-3">
								<button type="submit" class="btn btn-success" name="btnNotice">Add</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<div class="x_content">
		
		<h4>Award Table </h4>
		
		<div class="table-responsive">
			<table class="table table-striped jambo_table bulk_action">
				<thead>
					<tr class="headings">
						
						<th class="column-title">Award Name </th>
						<th class="column-title">Award Description</th>
						<th class="column-title">Award Type</th>
						<th class="column-title no-link last"><span class="nobr">Action</span>
						</th>
						
					</tr>
				</thead>
				
				<tbody>
					
				</tr>
				<tr class="odd pointer">
					
					<?php 
						$query="select * from award";
						$msg=$db->select($query);
						$i=0;
						if ($msg) {
							while ($result=$msg->fetch_assoc()) {
								$i++;	
							?>
							<td class=" "><?php echo($result['awardname']);?></td>
							<td class=" "><?php echo($result['awarddes']);?></td>
							<td class=" "><?php echo($result['awardTypeName']);?></td>
							<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delid=<?php echo($result['id']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
							</td>
						</tr>
					<?php } } ?>
					
			</tbody>
		</table>
	</div>
	
</div>
</div>
</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
	?>								