<body class="nav-md">
    <div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="index.html" class="site_title"><i  class="fa fa-lightbulb-o"></i> <span style = "font-size: 18px">DIU IDEA PORTAL</span></a>
					</div>
					
					<div class="clearfix"></div>
					
					<!-- menu profile quick info -->
					<div class="profile clearfix">
						<div class="profile_pic">
							<img src="<?php echo '../'.Session::get('image');?>" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
							<span>Welcome,</span>
							<h2><?php echo Session::get('name');?></h2>
						</div>
					</div>
					<!-- /menu profile quick info -->
					<br />
					
					<!-- sidebar menu -->
					<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
						<div class="menu_section">
							<h3>General</h3>
							<ul class="nav side-menu">
								<li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
									<ul class="nav child_menu">
										<li><a href="dashboard.php">Dashboard</a></li>
									</ul>
								</li>
								
								<?php 
									if(Session::get('role')==0){
									?>
									
									<li><a><i class="fa fa-user"></i> Manage User <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminAdduser.php">Add User</a></li>
											<li><a href="adminViewuser.php">View Student</a></li>
											<li><a href="adminviewSuperviseor.php">View Supervisor</a></li>
											<li><a href="adminviewHead.php">View Dept. Head</a></li>
										</ul>
									</li>
									
									
									<li><a><i class="fa fa-bullhorn"></i> Announcement <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminAnnounce.php">Announce</a></li>
											<li><a href="adminNoticeboard.php">Notice</a></li>
										</ul>
									</li>
									
									<li><a><i class="fa fa-edit"></i> Project Category <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminAddprojectType.php">Add Category</a></li>
										</ul>
									</li>
									<li><a><i class="fa fa-laptop"></i> Project Technology <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminAddTechnology.php">Add Technology</a></li>
										</ul>
									</li>
									<li><a><i class="fa fa-comments"></i> Manage Message <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminViewmessage.php">Student To Supervisor(Message)</a></li>
											<li><a href="adminViewmessage_1.php">Student To Admin(Message)</a></li>
											<li><a href="adminViewmessage_2.php">Supervisor To Admin(Message)</a></li>
										</ul>
									</li>
									
									
									<li><a><i class="fa fa-building"></i> Manage Department <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminaAddDepartment.php">Add Department</a></li>
										</ul>
									</li>
									<li><a><i class="fa fa-plane"></i> Best Projects <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminAddBestProject.php">Add Best Projects</a></li>
											<li><a href="adminViewBestProject.php">View Best Projects</a></li>
										</ul>
									</li>
									
									<li><a><i class="fa fa-trophy"></i> Award <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminAddAwardType.php">Add Award Type</a></li>
											<li><a href="adminAddAward.php">Add Award</a></li>
										</ul>
									</li>
									
									
									<li><a><i class="fa fa-lightbulb-o"></i> Manage Ideas<span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="adminViewIdeadetails.php">View Ideas</a></li>
										</ul>
									</li>
									
									
									
									<?php }else if(Session::get('role')==1){?>
									
									<li><a><i class="fa fa-edit"></i>Student Project<span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="supervisorViewProjectList.php">View Project List</a></li>
											<li><a href="supervisorViewAcceptedProjects.php">Accepted Projects</a></li>
										</ul>
									</li>
									<li><a><i class="fa fa-edit"></i> Student Messages <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="supervisorViewMessage.php">View Message</a></li>
										</ul>
									</li>
									<li><a><i class="fa fa-edit"></i> Head Messages <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="supervisorHeadViewMessage.php">View Message</a></li>
										</ul>
									</li>
									
									
									
									
									<?php }else if(Session::get('role')==2){?>
									
									
									
									
									<li><a><i class="fa fa-edit"></i>Student Project<span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="headViewProjectList.php">View Project List</a></li>
											<li><a href="headViewAcceptedProjects.php">Accepted Projects</a></li>
										</ul>
									</li>
									<li><a><i class="fa fa-edit"></i> Supervisor Message <span class="fa fa-chevron-down"></span></a>
										<ul class="nav child_menu">
											<li><a href="headViewMessage.php">View Message</a></li>
										</ul>
									</li>
									
									
									
								<?php }?>
							</ul>
						</div>
						
					</div>
					
					<div class="sidebar-footer hidden-small">
						<a data-toggle="tooltip" data-placement="top" title="Settings">
							<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
						</a>
						<a data-toggle="tooltip" data-placement="top" title="FullScreen">
							<span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
						</a>
						<a data-toggle="tooltip" data-placement="top" title="Lock">
							<span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
						</a>
						<a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
							<span class="glyphicon glyphicon-off" aria-hidden="true"></span>
						</a>
					</div>
					<!-- /menu footer buttons -->
				</div>
			</div>															