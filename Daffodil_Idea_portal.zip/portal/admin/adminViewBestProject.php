

<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>

<!-- top navigation -->
<?php
	include('inc/navbar.php');
?>


<?php 
	if (isset($_GET['delid'])) {
		$delid=$_GET['delid'];
		$delquery="delete from bestproject where BP_ID='$delid'";
		$deldmsg=$db->delete($delquery);
	}
?>



<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		
		<div class="clearfix"></div>
		
		<div class="col-md-12 col-sm-12  ">
			<div class="x_panel">
				<div class="x_title">
                    <h2>Best Projects Table<small>Custom design</small></h2>
                 
                    <div class="clearfix"></div>
				</div>
				
				<div class="x_content">
					
					<div class="table-responsive">
						<table class="table table-striped jambo_table bulk_action">
							<thead>
								<tr class="headings">
									
									<th class="column-title">Title </th>
									<th class="column-title">Category </th>
									<th class="column-title">Project Description </th>
									<th class="column-title">Award Description </th>
									<th class="column-title">Year </th>
									<th class="column-title">SupervisorEmail</th>
									<th class="column-title">Technology</th>
									
									
									<th class="column-title no-link last"><span class="nobr">Action</span>
									</th>
									
								</tr>
							</thead>
							
							<tbody>
								
								
								<tr class="odd pointer">
									
									
									<?php 
										$query="select * from bestproject";
										$msg=$db->select($query);
										$i=0;
										if ($msg) {
											while ($result=$msg->fetch_assoc()) {
												$i++;	
											?>
											<td class=" "><?php echo($result['Title']);?></td>
											<td class=" "><?php echo($result['Category']);?></td>
											<td class=" "><?php echo($result['Project_Des']);?></td>
											
											
											<td class=" "><?php echo($result['AwardDes']);?></td>
											<td class=" "><?php echo($result['year']);?></td>
											<td class=" "><?php echo($result['supervisorEmail']);?></td>
											<td class=" "><?php echo($result['projectTechnology']);?></td>
											
											<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delid=<?php echo($result['BP_ID']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
												
												<a href="?update=<?php echo($result['BP_ID']); ?>"><span style="color:green;font-size:19px;margin-left:10px;" class="glyphicon glyphicon-pencil"></span></a>
												
											</td>
										</tr>
									<?php } } ?>
									
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

</div>

</div>
</div>


<?php
	include('inc/footer.php');
?>	
