
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	$db=new Database();
?>


<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btnNotice'])) {
		
		$title=$fm->validation($_POST['title']);
		$linkdes=$fm->validation($_POST['linkdes']);
		
		$title=mysqli_real_escape_string($db->link,$title);
		$linkdes=mysqli_real_escape_string($db->link,$linkdes);
		
		
		
		if (empty($title)) {
			
			$error="Name field must not be empty!!";
			
			}elseif(empty($linkdes)){
			
			$error="Email field must not be empty!!";
			
			}else{
			
			$query = "INSERT INTO noticeboard(title,des)   
			VALUES('$title','$linkdes')";  
			$inserted_rows = $db->insert($query);    
			if ($inserted_rows) {  
				$msg="Add Data" ;  
				}else {   
				$error="Something is wrong!!!" ;  
			}
			
		}
	}
	
?>

<?php 
	if (isset($_GET['delid'])) {
		$delid=$_GET['delid'];
		$delquery="delete from noticeboard where Notice_ID='$delid'";
		$deldmsg=$db->delete($delquery);
	}
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
                <h3>Notice</h3>
			</div>
			
			<div class="title_right">
                <div class="col-md-5 col-sm-5  form-group pull-right top_search">
					<div class="input-group">
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 ">
			<div class="x_panel">
				<div class="x_title">
                    
                    <div class="clearfix"></div>
				</div>
				<div class="x_content">
                    <br />
					
					<?php 
						if (isset($error)) {
							
						?>
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Alert!</strong> <?php echo $error;?>
						</div>
						
					<?php } ?>
					
					<?php 
						if (isset($msg)) {
							
						?>
						<div class="alert alert-success alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Success!</strong> <?php echo $msg;?>
						</div>
						
					<?php } ?>
					
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="" method="post">
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Notice Title <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="title" required="required" class="form-control ">
							</div>
						</div>
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Description<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="linkdes" name="last-name" required="required" class="form-control">
							</div>
						</div>
						
						<div class="item form-group">
							<div class="col-md-6 col-sm-6 offset-md-3">
								<button type="submit" class="btn btn-success" name="btnNotice">Submit</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	
	<div class="x_content">
		
		<h4>Notice  Table </h4>
		
		<div class="table-responsive">
			<table class="table table-striped jambo_table bulk_action">
				<thead>
					<tr class="headings">
						<th class="column-title">SL </th>
						<th class="column-title">Title </th>
						<th class="column-title">Description </th>
						<th class="column-title">Date </th>
						<th class="column-title no-link last"><span class="nobr">Action</span>
						</th>
					</tr>
				</thead>
				<tbody>
				</tr>
				
				<?php 
					$query="select * from noticeboard";
					$msg=$db->select($query);
					$i=0;
					if ($msg) {
						while ($result=$msg->fetch_assoc()) {
							$i++;	
						?>
						<tr class="odd pointer">
							<td class=" "><?php echo($i);?></td>
							<td class=" "><?php echo($result['Title']);?></td>
							<td class=" "><?php echo($result['Des']);?></td>
						</td>
						<td class=" "><?php echo($result['Date']);?></td>
						
						<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delid=<?php echo($result['Notice_ID']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
							
						</td>
					</tr>
				<?php } } ?>
				
		</tbody>
	</table>
</div>

</div>

</div>
</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
	?>					