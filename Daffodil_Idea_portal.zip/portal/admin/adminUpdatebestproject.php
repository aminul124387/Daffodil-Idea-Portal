
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	$db=new Database();
?>


<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btnNotice'])) {
		
		
		$year=$fm->validation($_POST['year']);
		$projectTitle=$fm->validation($_POST['projectTitle']);
		$projectCategory=$fm->validation($_POST['projectCategory']);
		$projectDes=$fm->validation($_POST['projectDes']);
		$awardtype=$fm->validation($_POST['awardtype']);
		$m1=$fm->validation($_POST['m1']);
		$memberOne=$fm->validation($_POST['memberOne']);
		$memberTwo=$fm->validation($_POST['memberTwo']);
		$memberThree=$fm->validation($_POST['memberThree']);
		$supervisorEmail=$fm->validation($_POST['supervisorEmail']);
		$awardName=$fm->validation($_POST['awardName']);
		$projectTechonoloy=$fm->validation($_POST['projectTechonoloy']);
		
		
		$year=mysqli_real_escape_string($db->link,$year);
		$projectTitle=mysqli_real_escape_string($db->link,$projectTitle);
		$projectCategory=mysqli_real_escape_string($db->link,$projectCategory);
		$projectTechonoloy=mysqli_real_escape_string($db->link,$projectTechonoloy);
		$projectDes=mysqli_real_escape_string($db->link,$projectDes);
		$awardName=mysqli_real_escape_string($db->link,$awardName);
		$awardtype=mysqli_real_escape_string($db->link,$awardtype);
		$m1=mysqli_real_escape_string($db->link,$m1);
		$memberOne=mysqli_real_escape_string($db->link,$memberOne);
		$memberTwo=mysqli_real_escape_string($db->link,$memberTwo);
		$memberThree=mysqli_real_escape_string($db->link,$memberThree);
		$supervisorEmail=mysqli_real_escape_string($db->link,$supervisorEmail);
		
		
		if (empty($year) || $year == -1) {
			
			$error="Year field must not be empty!!";
			
			
			}elseif(empty($projectTitle)){
			
			$error="Project Title field must not be empty!!";
			
			}elseif(empty($projectCategory) || $projectCategory == -1 ){
			
			$error="Project Category must not be empty!!";
			
			}elseif(empty($projectTechonoloy) || $projectTechonoloy == -1 ){
			
			$error="Project Technology field must not be empty!!";
			
			}elseif(empty($projectDes)){
			
			$error="Project Description field must not be empty!!";
			
			}elseif(empty($awardName) || $awardName == -1){
			
			$error="Project Name field must not be empty!!";
			
			}elseif(empty($awardtype) || $awardtype == -1){
			
			$error="AwardType field must not be empty!!";
			
			}elseif(empty($m1)){
			
			$error="Member field must not be empty!!";
			
			}elseif(empty($supervisorEmail)){
			
			$error="Supervisor Email field must not be empty!!";
			
			
			}else{
			
			
			if(!empty($memberOne)){
				
				$memberOnequery="select * from users where email='$memberOne' limit 1";
				$memberOnecheck=$db->select($memberOnequery);
				
				}else if(!empty($memberTwo)){
				
				$memberTwoQuery="select * from users where email='$memberTwo' limit 1";
				$memberTwocheck=$db->select($memberTwoQuery);
				
				}else if(!empty($memberThree)){
				
				$memberThreeQuery="select * from users where email='$memberThree' limit 1";
				$memberThreecheck=$db->select($memberThreeQuery);
				
			}
			
			if ($memberOnecheck <> false || $memberTwocheck <> false || $memberThreecheck <> false) {
				
				$supervisorQuery="select * from users where email='$supervisorEmail' limit 1";
				$supervisorcheck=$db->select($supervisorQuery);
				
				if($supervisorcheck  <> false){
					
					$query = "INSERT INTO bestproject(Title,Category,Project_Des,AwardType,AwardDes,Team_Members,year,stdid_1,stdid_2,stdid_3,supervisorEmail,projectTechnology)   
					VALUES('$projectTitle','$projectCategory','$projectDes','$awardtype','$awardName','$m1','$year','$memberOne','$memberTwo','$memberThree','$supervisorEmail','$projectTechonoloy')";  
					
					$inserted_rows = $db->insert($query);    
					if ($inserted_rows) {  
						$msg="Add Info!!" ;  
						}else {   
						$error="Something is wrong!!!" ;  
					}
					
					}else{
					
					$error="Sorry!Invalid Supervisor email Already Exit!!";
					
				}
				
				}else{
				
				$error="Sorry!Invalid Member Info Already Exit!!";
				
			}
		}
	}
	
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<?php 
			if (isset($_GET['delid'])) {
				$delid=$_GET['delid'];
				$delquery="delete from department where id='$delid'";
				$deldmsg=$db->delete($delquery);
			}
		?>
		<div class="page-title">
			<div class="title_left">
                <h3>Best Projects</h3>
			</div>
			<div class="title_right">
                <div class="col-md-5 col-sm-5  form-group pull-right top_search">
					<div class="input-group">
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 ">
			<div class="x_panel">
				<div class="x_title">
                    <h2>Add Best Projects <small>different form elements</small></h2>
                    <div class="clearfix"></div>
				</div>
				<div class="x_content">
                    <br />
					<?php 
						if (isset($error)) {
							
						?>
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Alert!</strong> <?php echo $error;?>
						</div>
						
					<?php } ?>
					
					<?php 
						if (isset($msg)) {
							
						?>
						<div class="alert alert-success alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Success!</strong> <?php echo $msg;?>
						</div>
						
					<?php } ?>
					
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="" method="post">
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Supervisor Email<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="email" name="supervisorEmail" required="required" class="form-control ">
							</div>
						</div>
						
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Award Year<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<select class="form-control" name="year">
									<option value="-1">Select Year</option>
									<option >2017</option>
									<option >2018</option>
									<option >2019</option>
									<option >2020</option>
									<option >2021</option>
									<option >2022</option>
									<option >2023</option>
									<option >2024</option>
									<option >2025</option>
									<option >2026</option>
									<option>2027</option>
								</select>
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Project Title <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="projectTitle" required="required" class="form-control ">
							</div>
						</div>
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Category<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								
								<select class="form-control" name="projectCategory">
									<option value="-1">Select project Category</option>
									<?php 
										$query="select * from project_types";
										$msg=$db->select($query);
										$i=0;
										if ($msg) {
											while ($result=$msg->fetch_assoc()) {
												$i++;	
											?>
											<option value="<?php echo($result['name']);?>"><?php echo($result['name']);?></option>
										<?php } } ?>
								</select>
								
								
							</div>
						</div>
						
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Technology<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								
								<select class="form-control" name="projectTechonoloy">
									<option value="-1">Select Project Technology</option>
									<?php 
										$query="select * from technology";
										$msg=$db->select($query);
										$i=0;
										if ($msg) {
											while ($result=$msg->fetch_assoc()) {
												$i++;	
											?>
											<option value="<?php echo($result['technologyname']);?>"><?php echo($result['technologyname']);?></option>
										<?php } } ?>
								</select>
							</div>
						</div>
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Project Description<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<textarea class="form-control" rows="5" name="projectDes" required></textarea>
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Award Name<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<select class="form-control" name="awardName">
									<option value="-1">Select Award Name</option>
									<?php 
										$query="select * from award";
										$msg=$db->select($query);
										$i=0;
										if ($msg) {
											while ($result=$msg->fetch_assoc()) {
												$i++;	
											?>
											<option value="<?php echo($result['awardname']);?>"><?php echo($result['awardname']);?></option>
										<?php } } ?>
								</select>
								
							</div>
						</div>
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Award Type<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<select class="form-control" name="awardtype">
									<option value="-1">Select Award Type</option>
									<?php 
										$query="select * from awardtype";
										$msg=$db->select($query);
										$i=0;
										if ($msg) {
											while ($result=$msg->fetch_assoc()) {
												$i++;	
											?>
											<option value="<?php echo($result['awardtypename']);?>"><?php echo($result['awardtypename']);?></option>
										<?php } } ?>
								</select>
								
							</div>
						</div>
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Project Team Member<span class="required">*</span>
							</label>
							<div style="margin-top:8px;" class="col-md-6 col-sm-6 ">
								<label style="font-size:16px;" class="checkbox-inline"><input type="radio" name="m1" id="m1">Member 1</label>
								<label style="font-size:16px;" class="checkbox-inline"><input type="radio" name="m1" id="m2" >Member 2</label>
								<label style="font-size:16px;" class="checkbox-inline"><input type="radio" name="m1" id="m3" >Member 3</label>
								
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Member One Email <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="memberOne" id="memberOne" required="required" class="form-control" disabled required >
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Member Two Email<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="memberTwo" id="memberTwo" class="form-control" disabled required>
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Member Three Email<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="memberThree"  id="memberThree"  class="form-control" disabled required>
							</div>
						</div>
						
						
						<div class="item form-group">
							<div class="col-md-6 col-sm-6 offset-md-3">
								<button type="submit" class="btn btn-success" name="btnNotice">Add</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
	$(document).ready(function(){
		
		$("#m1").click(function(){
			$("#memberOne" ).prop( "disabled", false );
			$("#memberTwo" ).prop( "disabled", true );
			$("#memberThree" ).prop( "disabled", true );
			$("#memberTwo").val("");
			$("#memberThree").val("");
		});
		$("#m2").click(function(){
			$("#memberOne").prop( "disabled", false );
			$("#memberTwo").prop( "disabled", false );
			$("#memberThree").prop( "disabled", true );
			$("#memberThree").val("");
			
		});
		$("#m3").click(function(){
			$( "#memberOne" ).prop( "disabled", false );
			$( "#memberTwo" ).prop( "disabled", false );
			$( "#memberThree" ).prop( "disabled", false );
			
		});
	});
</script>

<?php
	include('inc/footer.php');
	?>												