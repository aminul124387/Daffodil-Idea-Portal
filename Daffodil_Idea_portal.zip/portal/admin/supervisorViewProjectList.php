
<?php 
$connection = mysqli_connect('localhost', 'root', '', 'idea');
	if (isset($_GET['accept'])) {
		$id=$_GET['accept'];
		$upquery="UPDATE ideas SET status = 2 WHERE id='$id'";
		$runSql=$connection->query($upquery);
	}
	if (isset($_GET['reject'])) {
		$id=$_GET['reject'];
		$upquery="UPDATE ideas SET status =-1 WHERE id='$id'";
		$runSql=$connection->query($upquery);
	}
?>

<?php 

include('inc/header.php');
include('inc/sidebar.php');
 ?>

        <!-- top navigation -->
<?php
include('inc/navbar.php');
?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">

              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Table design <small>Custom design</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        
                      </li>
                      <li><a><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

           

                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title">SL </th>
                            <th class="column-title">Project Name </th>
                            <th class="column-title">User ID </th>
                            <th class="column-title">Image </th>
                            <th class="column-title">Content</th>
                            <th class="column-title">Status</th>
                            <th class="column-title">Created at</th>
                            <th class="column-title">Updated at</th>
                            <th class="column-title no-link last"><span class="nobr">Action</span>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          <?php 
							$query="select * from ideas";
							$msg=$db->select($query);
							$i=0;
							if ($msg) {
								while ($result=$msg->fetch_assoc()) {
									$i++;	
								?>
                          <tr class="odd pointer">
                            <td class=" "><?php echo $i;?></td>
                            <td class=" "><?php echo($result['name']);?></td>
                            <td class=" "><?php echo($result['user_id']);?></td>
                            </td>
                            <td class="text-center"><?php echo "<img src='". @$result['image'] . "'height='70' width='120'>"; ?>
														</td>
                            <td class=" "><?php echo($result['content']);?></td>
                            <td class="a-right a-right "><?php if($result['status']=='1'){?>Pending<?php }elseif($result['status']=='2' || $result['status']=='3'){?>Confirmed <?php }elseif($result['status']=='-1'){?>Rejected <?php }?></td>
                            <td class="a-right a-right "><?php echo($result['created_at']);?></td>
                            <td class="a-right a-right "><?php echo($result['updated_at']);?></td>
                            <td class=" last">
                            	<?php if( $result['status'] != -1){?>
                            	<a href="?accept=<?php echo $result['id']; ?>" ><span class="glyphicon glyphicon-ok" title="Accept" ></span></a>
                            <?php } if( $result['status'] != 2 || $result['status'] != 3){?>
                            	<a href="?reject=<?php echo $result['id']; ?>"><span class="glyphicon glyphicon-ban-circle" title="Reject"></span></a>
                            <?php }?>
                            	<a href="supervisorFeedback.php?idea_id=<?php echo $result['id']; ?>"><span class="glyphicon glyphicon-eye-open" title="Feedback"></span></a>
                            </td>
                          </tr>
                          <?php } } ?>
                        </tbody>
                      </table>
                    </div>					
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>    
      </div>
    </div>
<?php
	include('inc/footer.php');
	?>	
