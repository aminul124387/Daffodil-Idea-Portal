
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	$db=new Database();
?>


<?php 
	if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btnNotice'])) {
		
		$title=$fm->validation($_POST['title']);
		$linkdes=$fm->validation($_POST['linkdes']);
		
		$title=mysqli_real_escape_string($db->link,$title);
		$linkdes=mysqli_real_escape_string($db->link,$linkdes);
		
		
		
		if (empty($title)) {
			
			$error="Name field must not be empty!!";
			
			}elseif(empty($linkdes)){
			
			$error="Email field must not be empty!!";
			
			}else{
			
			$mailquery="select * from department where name='$title' limit 1";
			$namecheck=$db->select($mailquery);
			
			$mailquery_cd="select * from department where name_cd='$linkdes' limit 1";
			$name_cdcheck=$db->select($mailquery_cd);
			
			if ($namecheck <> false || $name_cdcheck <> false) {
				
             	$error="Sorry!Department Name Already Exit!!";
				
				}else{
				
				$query = "INSERT INTO department(name,name_cd)   
				VALUES('$title','$linkdes')";  
				$inserted_rows = $db->insert($query);    
				if ($inserted_rows) {  
					$msg="Add Data" ;  
					}else {   
					$error="Something is wrong!!!" ;  
				}
			}
		}
	}
	
?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
	<?php 
			if (isset($_GET['delid'])) {
				$delid=$_GET['delid'];
				$delquery="delete from department where id='$delid'";
				$deldmsg=$db->delete($delquery);
			}
		?>
		<div class="page-title">
			<div class="title_left">
                <h3>Form Elements</h3>
			</div>
			
			<div class="title_right">
                <div class="col-md-5 col-sm-5  form-group pull-right top_search">
					<div class="input-group">
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 ">
			<div class="x_panel">
				<div class="x_title">
                    <h2>Form Design <small>different form elements</small></h2>
                    <div class="clearfix"></div>
				</div>
				<div class="x_content">
                    <br />
					<?php 
						if (isset($error)) {
							
						?>
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Alert!</strong> <?php echo $error;?>
						</div>
						
					<?php } ?>
					
					<?php 
						if (isset($msg)) {
							
						?>
						<div class="alert alert-success alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Success!</strong> <?php echo $msg;?>
						</div>
						
					<?php } ?>
					
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="" method="post">
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Department Name <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="title" required="required" class="form-control ">
							</div>
						</div>
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Department CD <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="linkdes" name="last-name" required="required" class="form-control">
							</div>
						</div>
						
						<div class="item form-group">
							<div class="col-md-6 col-sm-6 offset-md-3">
								<button type="submit" class="btn btn-success" name="btnNotice">Add</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<div class="x_content">
		
		<h4>Notice  Table </h4>
		
		<div class="table-responsive">
			<table class="table table-striped jambo_table bulk_action">
				<thead>
					<tr class="headings">
						
						<th class="column-title">DepartmentName </th>
						<th class="column-title">Department CD </th>
						<th class="column-title no-link last"><span class="nobr">Action</span>
						</th>
						
					</tr>
				</thead>
				
				<tbody>
					
				</tr>
				<tr class="odd pointer">
					
					<?php 
							$query="select * from department";
							$msg=$db->select($query);
							$i=0;
							if ($msg) {
								while ($result=$msg->fetch_assoc()) {
									$i++;	
								?>
								<td class=" "><?php echo($result['name']);?></td>
								<td class=" "><?php echo($result['name_cd']);?></td>
								<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delid=<?php echo($result['id']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
								</td>
								</tr>
							<?php } } ?>
				
			</tbody>
		</table>
	</div>

</div>
</div>
</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
	?>					