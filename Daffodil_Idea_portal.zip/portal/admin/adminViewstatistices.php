
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	$db=new Database();
?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		
		<div class="clearfix"></div>
		
		<div class="x_content">
			
			<h4 style="margin-bottom:40px;font-weight:bold;">Graph Details </h4>
			
			<div class="table-responsive">
				
				
				
				<div class="col-md-12">
					
					<div class="col-md-4">
						<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
						<script type="text/javascript">  
							google.charts.load('current', {'packages':['corechart']});  
							google.charts.setOnLoadCallback(drawChart);  
							
							function drawChart()  
							{  
								var data = google.visualization.arrayToDataTable([  
								['Gender', 'Number'],  
								<?php 
									$aa='<div>Brand : <b>$row["productName"]</b><br/>Total Revenue : <b></div>';
									$query = "SELECT * FROM awardtype";
									$msg=$db->select($query);
									$ss="";
									$dd="";
									if ($msg) {
										while ($result=$msg->fetch_assoc()) {
											$ss=$result["id"];
											$dd=$result["awardtypename"];
											echo "['M :".$dd."',".$ss."],";
										}
										
									}
									
								?>
								
								]);  
								var options = {  
									title: 'Percentage of total customer',  
									is3D:true,  
									// pieHole: 0.4  
								};  
								var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
								chart.draw(data, options);  
							}  
						</script>  
						<div id="piechart" style="width:320px; height: 200px;"></div>
						
					</div>
					
					<div class="col-md-4">
						
						<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
						<script type="text/javascript">  
							google.charts.load('current', {'packages':['corechart']});  
							google.charts.setOnLoadCallback(drawChart);  
							
							function drawChart()  
							{  
								var data = google.visualization.arrayToDataTable([  
								['Gender', 'Number'],  
								<?php 
									
									$query = "SELECT * FROM awardtype";
									$msg=$db->select($query);
									$ss="";
									$dd="";
									if ($msg) {
										while ($result=$msg->fetch_assoc()) {
											$ss=$result["id"];
											$dd=$result["awardtypename"];
											echo "['M :".$dd."',".$ss."],";
										}
										
									}
									
								?>
								
								]);  
								var options = {  
									title: 'Percentage total customer order',  
									is3D:true,  
									// pieHole: 0.4  
								};  
								var chart = new google.visualization.PieChart(document.getElementById('pie'));  
								chart.draw(data, options);  
							}  
						</script>  
						<div id="pie" style="width: 320px; height: 200px;"></div>
					</div>
					
					
					<div class="col-md-4">
						
						<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
						<script type="text/javascript">  
							google.charts.load('current', {'packages':['corechart']});  
							google.charts.setOnLoadCallback(drawChart);  
							
							function drawChart()  
							{  
								var data = google.visualization.arrayToDataTable([  
								['Gender', 'Number'],  
								<?php 
									
									$query = "SELECT * FROM awardtype";
									$msg=$db->select($query);
									$ss="";
									$dd="";
									if ($msg) {
										while ($result=$msg->fetch_assoc()) {
											$ss=$result["id"];
											$dd=$result["awardtypename"];
											echo "['M :".$dd."',".$ss."],";
										}
										
									}
									
									?>
								
								]);  
								var options = {  
									title: 'Percentage total customer order',  
									is3D:true,  
									// pieHole: 0.4  
								};  
								var chart = new google.visualization.PieChart(document.getElementById('pie1'));  
								chart.draw(data, options);  
							}  
						</script>  
						<div id="pie1" style="width: 320px; height: 200px;"></div>
					</div>
					
					
					
					
					
				</div>
				
				
				
				
				
				
				<div class="col-md-12">
					<h3 style="text-align:center;font-style:bold;color:#2769A1;">*** Chart Report For Month ***</h3>
					<div class="col-md-12">
						
						
						<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
						<script type="text/javascript">  
							
							google.charts.load("visualization","1", {packages:['corechart']});		   
							google.charts.setOnLoadCallback(drawChart);  
							
							function drawChart()  
							{  
								var data = google.visualization.arrayToDataTable([  
								['Gender', 'Number'],  
								<?php 
									
									$query = "SELECT * FROM awardtype";
									$msg=$db->select($query);
									$ss="";
									$dd="";
									if ($msg) {
										while ($result=$msg->fetch_assoc()) {
											$ss=$result["id"];
											$dd=$result["awardtypename"];
											echo "['M :".$dd."',".$ss."],";
										}
									}
								?>
								]);
								var options = {  
									title: 'Percentage of total sellprice',  
									is3D:true,  
									// pieHole: 0.4  
								};  
								var chart = new google.visualization.ColumnChart(document.getElementById('java'));  
								chart.draw(data, options);  
							}  
						</script>  
						<div id="java" style="width:920px; height:400px;"></div>
						
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
	?>								