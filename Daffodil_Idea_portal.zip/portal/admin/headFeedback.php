
<?php 
include('inc/header.php');
include('inc/sidebar.php');
?>
<?php
include('inc/navbar.php');
$db=new Database();
@$idea_id=$_GET['idea_id'];
$query1="SELECT f.feedback_id,f.feedback,f.c_date,i.name from feedbacks f INNER JOIN ideas i ON f.idea_id=i.id WHERE idea_id = '$idea_id'";
		$runSQL=$db->select($query1);
		$result1=mysqli_fetch_assoc($runSQL);

?>


<?php 
if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btnFeedback'])) {
	@session_start();
	$feedback=$fm->validation($_POST['feedback']);
	$idea_id=$_GET['idea_id'];
	$user_id=$_SESSION['id'];
	date_default_timezone_set('Asia/Dhaka');
    $c_date=date('m/d/Y');

	if (empty($feedback)) {

		$error="Name field must not be empty!!";

	}else{
		$query = "INSERT INTO feedbacks(idea_id,user_id,feedback,c_date)   
		VALUES('$idea_id','$user_id','$feedback','$c_date')";  
		$inserted_rows = $db->insert($query);    
		if ($inserted_rows) {  
			$msg="Add Data" ;  
		}else {   
			$error="Something is wrong!!!" ;  
		}
	}
}

?>
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<?php 
		if (isset($_GET['delete'])) {
			@$idea_id=$_GET['idea_id'];
			$feedback_id=$_GET['delete'];
			$delquery="DELETE FROM feedbacks WHERE feedback_id='$feedback_id'";
			$deldmsg=$db->delete($delquery);
			header('location:headViewProjectList.php');
		}
		?>
		<div class="page-title">
			<div class="title_left">
				<h3>Project Feedback</h3>
			</div>
			
			<div class="title_right">
				<div class="col-md-5 col-sm-5  form-group pull-right top_search">
					<div class="input-group">
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 ">
			<div class="x_panel">
				<div class="x_title">
					<h2>Project : <small><?php echo($result1['name']);?></small></h2>
					<div class="clearfix"></div>
				</div>
				<div class="x_content">
					<br />
					<?php 
					if (isset($error)) {

						?>
						<div class="alert alert-danger alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Alert!</strong> <?php echo $error;?>
						</div>
						
					<?php } ?>
					
					<?php 
					if (isset($msg)) {

						?>
						<div class="alert alert-success alert-dismissible">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Success!</strong> <?php echo $msg;?>
						</div>
						
					<?php } ?>
					
					<form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="" method="post">
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="feedback">Feedback <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" name="feedback" required="required" class="form-control ">
								<input type="hidden" name="idea_id" value="<?php echo $idea_id; ?>" class="form-control ">
							</div>
						</div>
						
						<div class="item form-group">
							<div class="col-md-6 col-sm-6 offset-md-3">
								<button type="submit" class="btn btn-success" name="btnFeedback">Submit</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<div class="x_content">
		
		<h4>Feedback Table </h4>
		
		<div class="table-responsive">
			<table class="table table-striped jambo_table bulk_action">
				<thead>
					<tr class="headings">
						
						<th class="column-title">Feedback ID </th>
						<th class="column-title">Project Name</th>
						<th class="column-title">Feedback</th>
						<th class="column-title">Date</th>
						<th class="column-title no-link last"><span class="nobr">Action</span>
						</th>
						
					</tr>
				</thead>
				
				<tbody>
					
				</tr>
				<tr class="odd pointer">
					
					<?php 
					$idea_id=$_GET['idea_id'];
					$query="SELECT f.feedback_id,f.user_id,f.feedback,f.c_date,i.name from feedbacks f INNER JOIN ideas i ON f.idea_id=i.id WHERE idea_id = '$idea_id'";
					$msg=$db->select($query);
					if ($msg) {
						while ($result=$msg->fetch_assoc()) {
							?>
							<td class=" "><?php echo($result['feedback_id']);?></td>
							<td class=" "><?php echo($result['name']);?></td>
							<td class=" "><?php echo($result['feedback']);?></td>
							<td class=" "><?php echo($result['c_date']);?></td>
							<?php 
							@session_start();
							$id=$_SESSION['id'];
							if($result['user_id'] != '$id' ){?>
							<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delete=<?php echo($result['feedback_id']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
							</td>
						<?php } ?>
						</tr>
					<?php } } ?>

				</tbody>
			</table>
		</div>

	</div>
</div>
</div>
</div>
</div>
</div>

<?php
include('inc/footer.php');
?>					