
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	$db=new Database();
?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<?php 
			if (isset($_GET['delid'])) {
				$delid=$_GET['delid'];
				$delquery="delete from message where Message_ID='$delid'";
				$deldmsg=$db->delete($delquery);
			}
		?>
		<div class="clearfix"></div>
		
		<div class="x_content">
			
			<h4 style="margin-bottom:40px;font-weight:bold;">Message Table </h4>
			
			<div class="table-responsive">
				<table class="table table-striped jambo_table bulk_action">
					<thead>
						<tr class="headings">
							
							<th class="column-title">Name </th>
					        <th class="column-title">Comment </th>
							<th class="column-title">Date </th>
							<th class="column-title no-link last"><span class="nobr">Action</span>
							</th>
						</tr>
					</thead>
					
					<tbody>
						
						<?php 
							$query="select * from message";
							$msg=$db->select($query);
							$i=0;
							if ($msg) {
								while ($result=$msg->fetch_assoc()) {
									$i++;	
								?>
								<td class=" "><?php echo($result['Title']);?></td>
								<td class=" "><?php echo($result['Comment']);?></td>
								<td class=" "><?php echo($result['message_date']);?></td>
								<td class="last"><a onclick="return confirm('Do you want to delete!!!');" href="?delid=<?php echo($result['Message_ID']); ?>"><span style="color:red;font-size:19px;" class="glyphicon glyphicon-trash"></span></a>
								</td>
							<?php } } ?>
					</tbody>
				</table>
			</div>
		</div>
		
	</div>
</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
	?>						