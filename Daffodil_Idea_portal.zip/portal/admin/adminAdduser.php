
<?php 
	include('inc/header.php');
	include('inc/sidebar.php');
?>
<?php
	include('inc/navbar.php');
	include_once'../classes/Department.php';
	$department=new Department();
	if ($_SERVER['REQUEST_METHOD']=='POST'&& isset($_POST['adduser'])) {
 	$userReg=$department->addUser($_POST,$_FILES);
   }
?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
                <h3>Add Users</h3>
			</div>
			<div class="title_right">
                <div class="col-md-5 col-sm-5  form-group pull-right top_search">
					<div class="input-group">
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 ">
			<div class="x_panel">
				
				<div class="x_content">
                    <br />
                    <?php if(isset($_SESSION['error'])) {?>
                      <div class="alert alert-warning alert-dismissible" data-auto-dismiss="2000" role="alert">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <strong style="color: red;">Warning!</strong>
                           <?php echo($_SESSION['error']);

                           unset($_SESSION['error']);
                           ?>
                      </div>
                    <?php }?>
                    <?php if(isset($_SESSION['success'])) {?>
                    <div class="alert alert-success alert-dismissible" data-auto-dismiss="2000" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <strong style="color: green;">Success!</strong> 
                        <?php echo($_SESSION['success']);

                           unset($_SESSION['success']);
                           ?>
                      </div>
                    <?php }?>
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" action="">
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Name <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="text" id="first-name" required="required" class="form-control " name="name">
							</div>
						</div>
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="email">Email <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<input type="email" id="first-name" required="required" class="form-control " name="email">
							</div>
						</div>
						
						
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for=" department">Department<span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								 <select class="form-control" name="department">
								     <option value=" ">Select Department</option>
								     <?php 
	                                $getidea=$department->getDepartment();
	                                if ($getidea) {
	                                   while ($result=$getidea->fetch_assoc()) {
	                                 ?>
								     <option value="<?php echo($result['name_cd']);?>"><?php echo($result['name']);?></option>
									  <?php }} ?>
								   </select>
							</div>
						</div>
						
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align">Semester <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<select class="form-control" name="semister">
							     <option value=" ">Select Semister</option>
							     <option value="spring">Spring</option>
							     <option value="fall">Fall</option>
							     <option value="summar">Summar</option>
							   </select>
							</div>
						</div>
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="language">Language <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
			   					<input type="text" id="tags" value="Php,Laravel,Bootstrap" class="form-control" name="language" data-role="tagsinput">
							</div>
						</div>
						<div class="item form-group">
							<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Type <span class="required">*</span>
							</label>
							<div class="col-md-6 col-sm-6 ">
								<select class="form-control" name="role">
							     <option value=" ">Select Type</option>
							     <option value="1">Supervisor</option>
								  <option value="2">Department Head</option>
							   </select>
							</div>
						</div>
						
						
						<div class="ln_solid"></div>
						<div class="item form-group">
							<div class="col-md-6 col-sm-6 offset-md-3">
							<button type="submit" class="btn btn-success" name="adduser">Submit</button>
							
								
							</div>
						</div>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
</div>

<?php
	include('inc/footer.php');
?>	
<script>
$( document ).ready(function() {
	console.log( "ready yrar!" );
$('#tags').tagsInput({
      width: 'auto'
    });
});
</script>