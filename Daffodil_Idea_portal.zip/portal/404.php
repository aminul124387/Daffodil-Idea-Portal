<?php include("inc/header.php"); ?>
<div class="ps-404">
      <div class="container">
        <h1>404</h1>
        <h3>Page not found</h3>
        <p>We are looking for your page … but we can’t find it</p><a class="ps-btn ps-btn--yellow" href="index.php">Back To Home</a>
        <div class="ps-404__image"><img src="images/404.jpg" alt=""></div>
      </div>
</div>
<?php include("inc/footer.php"); ?>